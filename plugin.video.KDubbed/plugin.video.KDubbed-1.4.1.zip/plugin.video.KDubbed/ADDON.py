# ─── Standard Library ────────────────────────────────
import sys
import os
import re
import json
import time
import base64
import string
import gzip
import ast
import xml.dom.minidom

# ─── Python 2/3 Compatibility (six) ──────────────────
import six
from six import BytesIO
from six.moves.urllib.parse import quote_plus
from six.moves.urllib import parse as urllib

try:
    import urllib.request as urllib2  # Python 3
except ImportError:
    import urllib2  # Python 2 fallback

if six.PY3:
    from http import cookiejar as cookielib
else:
    import cookielib

# ─── Kodi Modules ────────────────────────────────────
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs

# ─── Third-Party Libraries ───────────────────────────
import requests
from bs4 import BeautifulSoup
import resolveurl
from urllib.parse import urljoin  # modern replacement for url join logic

# ─── Custom & External ───────────────────────────────
import dodge  # for khmertv
dodge = dodge.console  # compatibility fix / abstraction layer

# ─── t0mm0 Common Library (Legacy Kodi) ─────────────
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net


ABOUT_SHOWN_CACHE = {}

# ─── Add-on Info ─────────────────────────────────────
ADDON_ID = 'plugin.video.KDubbed'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_PROFILE = ADDON.getAddonInfo('profile')
DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')
PLUGIN_HANDLE = int(sys.argv[1])

# ─── Paths ───────────────────────────────────────────
COOKIE_JAR = os.path.join(DATA_PATH, 'khmerstream.lwp')
IMAGE_PATH = os.path.join(ADDON_PATH, 'resources', 'images')
FANART = os.path.join(IMAGE_PATH, 'Angkor4.jpg')

# ─── Icons ───────────────────────────────────────────
ICON_URL = 'http://radio.js-cambodia.com/'
ICON_SEARCH = os.path.join(IMAGE_PATH, 'search1.png')
ICON_YOUTUBE = os.path.join(IMAGE_PATH, 'playlist.png')
ICON_MOVIE9 = os.path.join(IMAGE_PATH, 'movie9.png')
ICON_JOLCHET = os.path.join(IMAGE_PATH, 'icon.png')
ICON_KHMERTV = os.path.join(IMAGE_PATH, 'khmertv.png')

# ─── Base URLs ───────────────────────────────────────
VIDEO4KHMER = 'https://www.video4khmer36.com/'
PHUMIK = 'https://phumikhmer2.com/'
KHMERAVENUE = 'https://www.khmeravenue.com/'
MERLKON = 'https://www.khmerdrama.com/'
KHMER4 = 'https://www.khmer4holiday.com/'

# ─── Headers ─────────────────────────────────────────
USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"


# ─── Utility Functions ─────────────────────────────
def _fetch_url(url, user_agent=USER_AGENT, as_text=False, timeout=10, retries=3, delay=2):
    headers = {'User-Agent': user_agent}
    for attempt in range(retries):
        try:
            r = requests.get(url, headers=headers, timeout=timeout)
            r.raise_for_status()
            return r.text if as_text else r.content
        except requests.exceptions.Timeout:
            xbmc.log(f"[{ADDON_ID}] Timeout ({attempt + 1}) on: {url}", xbmc.LOGWARNING)
        except requests.exceptions.RequestException as e:
            xbmc.log(f"[{ADDON_ID}] Request error ({attempt + 1}): {e}", xbmc.LOGWARNING)
        time.sleep(delay)
    xbmc.log(f"[{ADDON_ID}] Failed after {retries} attempts: {url}", xbmc.LOGERROR)
    return '' if as_text else b''

def OpenURL(url, **kwargs):
    return _fetch_url(url, as_text=False, **kwargs)

def OpenSoup(url, **kwargs):
    return _fetch_url(url, as_text=True, **kwargs)

def GetInput(message, heading, is_hidden=False):
    kb = xbmc.Keyboard("", message, is_hidden)
    kb.setHeading(heading)
    kb.doModal()
    return kb.getText() if kb.isConfirmed() else ""


# Main Menu
def HOME():
    addDir("[COLOR yellow][B][I]SEARCH[/I][/B][/COLOR]", MERLKON, 5, ICON_SEARCH)
    addDir("Khmer Live TV - MIGHT NOT WORK", ICON_URL, 11, ICON_KHMERTV)

    # ─── KHMERAVENUE ───────────────────────────────
    KHMERAVENUE_LOGO = 'https://www.khmeravenue.com/wp-content/themes/avenue/img/logo.png'
    addDir('============= [COLOR red] KHMERAVENUE [/COLOR] =============', "", 21, KHMERAVENUE_LOGO)
    khmerave_categories = [
        ("Chinese", f'{KHMERAVENUE}album/', 21),
        ("Korean", f'{KHMERAVENUE}country/korea/', 23),
    ]
    for label, url, mode in khmerave_categories:
        addDir(label, url, mode, KHMERAVENUE_LOGO)

    # ─── MERLKON ───────────────────────────────────
    MERLKON_LOGO = 'https://www.khmerdrama.com/wp-content/themes/avenue/img/logo.png'
    merlkon_categories = [
        ("Thai HD", f'{MERLKON}country/thailand/'),
        ("Thai Boran", f'{MERLKON}genre/thai-boran/'),
        ("Thai Horror", f'{MERLKON}genre/horror/'),
        ("Thai Mayura", f'{MERLKON}dubbed/mayura/'),
        ("Thai KM", f'{MERLKON}dubbed/km/'),
        ("Indian", f'{MERLKON}country/India/'),
        ("Philippines", f'{MERLKON}country/philippines/'),
        ("Cambodia", f'{MERLKON}country/cambodia/'),
        ("Kon", f'{MERLKON}albumcategory/kon/'),
    ]
    for label, url in merlkon_categories:
        addDir(label, url, 22, MERLKON_LOGO)

    # ─── VIDEO4KHMER ───────────────────────────────
    V4K_LOGO = 'https://www.video4khmer36.com/templates/pkakrovan/images/all/logo.png'
    addDir('============= [COLOR red] VIDEO4KHMER [/COLOR] =============', "", 31, V4K_LOGO)
    video4k_categories = [
        ("Cambodia", f'{VIDEO4KHMER}khmer-movie-category/khmer-drama-watch-online-free-catalogue-504-page-1.html'),
        ("Chinese Aired", f'{VIDEO4KHMER}khmer-movie-category/chinese-series-drama-to-be-continued-catalogue-2673-page-1.html'),
        ("Chinese Completed", f'{VIDEO4KHMER}khmer-movie-category/chinese-series-drama-watch-online-free-catalogue-506-page-1.html'),
        ("Thai Aired", f'{VIDEO4KHMER}khmer-movie-category/thai-lakorn-drama-to-be-continued-catalogue-2674-page-1.html'),
        ("Thai Completed", f'{VIDEO4KHMER}khmer-movie-category/thai-lakorn-drama-watch-online-free-catalogue-537-page-1.html'),
        ("Korean Aired", f'{VIDEO4KHMER}khmer-movie-category/korean-drama-to-be-continued-catalogue-508-page-1.html'),
        ("Korean Completed", f'{VIDEO4KHMER}khmer-movie-category/korean-drama-watch-online-free-catalogue-507-page-1.html'),
    ]
    for label, url in video4k_categories:
        addDir(label, url, 31, V4K_LOGO)

    # ─── KHMER4HOLIDAY / PHUMIK ─────────────────────
    KHMER4_LOGO = 'https://1.bp.blogspot.com/-9Y8PknwGtEE/YVp_qF4rR-I/AAAAAAAABAg/k4IED_8_o34L--XjAoMYZ6SwCKQgMZJkwCLcBGAsYHQ/s754/Khmer4Holiday.png'
    addDir('============= [COLOR red] KHMER4HOLIDAY [/COLOR] =============', "", 101, KHMER4_LOGO)
    khmer4_categories = [
        ("Khmer", f'{KHMER4}search/label/Khmer%20Drama?&max-results=24'),
        ("Thai", f'{KHMER4}search/label/Thai%20Drama?&max-results=24'),
        ("Chinese", f'{KHMER4}search/label/Chines%20Drama?&max-results=24'),
        ("Korean", f'{KHMER4}search/label/Korea%20Drama?&max-results=24'),
    ]
    for label, url in khmer4_categories:
        addDir(label, url, 101, KHMER4_LOGO)

    # PHUMIK (added under Khmer4 section)
    addDir('Thai4', f'{PHUMIK}?video=Thai-Drama&cat-id=18', 91, 'https://phumikhmer2.com/home/img/logo.png')

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# Search Function    
def SEARCH():
    sources = [
        ('KhmerAvenue', 201),
        ('Merlkon', 202),
        ('Khmer4Holiday', 203),
        ('PhumiKhmer2', 204),
        ('Video4Khmer36', 205)
    ]
    dialog = xbmcgui.Dialog()
    choice = dialog.select('Search From:', [s[0] for s in sources])
    if choice == -1:
        return

    keyb = xbmc.Keyboard('', 'Enter Search Text')
    keyb.doModal()
    if not keyb.isConfirmed():
        return

    search_text = keyb.getText()
    encoded_text = quote_plus(search_text)

    source = sources[choice][0]

    if source == 'KhmerAvenue':
        SINDEX_GENERIC(f'{KHMERAVENUE}?s={encoded_text}', '[COLOR yellow]KHMERAVE[/COLOR]')
    elif source == 'Merlkon':
        SINDEX_GENERIC(f'{MERLKON}?s={encoded_text}', '[COLOR cyan]MELKON[/COLOR]')
    elif source == 'Khmer4Holiday':
        SINDEX_KHMER4(f'{KHMER4}search?q={encoded_text}')
    elif source == 'PhumiKhmer2':
        SINDEX_PHUMIK(f'{PHUMIK}?search={encoded_text}')
    elif source == 'Video4Khmer36':
        SEARCH_VIDEO4U(search_text)
    


# KhmerTV Stream List
def KHMERYV(url):
    try:
        link = dodge.channel(url)

        # Normalize to str for regex parsing
        if isinstance(link, bytes):
            content = link.decode('utf-8')
        else:
            try:
                content = link.encode('utf-8').decode('utf-8')
            except Exception:
                content = link  # fallback if already clean

        match = re.findall(r"<title>(.+?)</title>\s*<link>(.+?)</link>\s*<thumbnail>(.+?)</thumbnail>", content)
        for vLinkName, vLink, vImage in match:
            mode = 2 if 'dodge' in vLink else 4
            addLink(vLinkName, vLink, mode, vImage)

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] KHMERYV failed: {e}", xbmc.LOGERROR)	
		
# KhmerTV end

############## VIDEO4KHMER ****************** 
def parse_video_thumbnails(soup, title_suffix='', mode=35):
    for div in soup.find_all('div', class_='cover-thumb'):
        a_tag = div.find('a')
        if not a_tag:
            continue
        style = div.get('style', '')
        v_link = a_tag.get('href')
        v_title = a_tag.get('title', 'No Title') + title_suffix
        v_image = style.replace('background-image: url(', '').replace(')', '').strip()
        addDir(v_title, v_link, mode, v_image)

def parse_pagination(soup, mode=31):
    pagination = soup.find('ul', class_='pagination')
    if pagination:
        for a in pagination.find_all('a'):
            page_url = a.get('href')
            page_num = re.sub(r'<i[^>]*></i>', '', a.decode_contents().strip())
            addDir(f"Page {page_num}", page_url, mode, "")

def INDEX_VIDEO4U(url):
    soup = BeautifulSoup(OpenSoup(url), 'html.parser')
    parse_video_thumbnails(soup)
    parse_pagination(soup)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def SEARCH_VIDEO4U(search_term):
    url = f"https://www.video4khmer36.com/search.php?keywords={quote_plus(search_term)}&page=1"
    soup = BeautifulSoup(OpenSoup(url), 'html.parser')
    parse_video_thumbnails(soup, title_suffix=' [COLOR red]VIDEO4KHMER[/COLOR]')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def EPISODE_VIDEO4U(url, name):
    html = OpenSoup(url)
    decoded = html.decode("utf-8", errors="ignore") if isinstance(html, bytes) else html
    soup = BeautifulSoup(decoded, 'html.parser')

    # --- Show Summary once per episode URL ---
    if ADDON.getSetting("summary_url") != url:
        h2 = soup.find('h2', string=lambda s: s and 'Summary' in s)
        if h2:
            p = h2.find_next_sibling('p')
            if p:
                summary = p.get_text(separator='\n', strip=True)
                try:
                    xbmcgui.Dialog().textviewer("Summary", summary)
                    ADDON.setSetting("summary_url", url)
                except Exception as e:
                    xbmc.log(f"[{ADDON_ID}] Summary popup failed: {e}", xbmc.LOGWARNING)

    # --- Show the current item itself ---
    addLink(name, url, 3, '')

    # --- Parse the actual episode table ---
    table = soup.find('table', id='episode-list')
    if not table:
        xbmc.log(f"[{ADDON_ID}] No episode table found at {url}", xbmc.LOGWARNING)
        return

    for tr in table.find_all('tr'):
        td = tr.find('td')
        if not td:
            continue

        a_tag = td.find('a', href=True)
        if not a_tag:
            continue

        v_link = a_tag['href']
        v_title = a_tag.get_text(strip=True).replace("Episode", "Part")

        addLink(v_title, v_link, 3, '')


    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)





############## phumikhmer2 ****************** 
def parse_phumik_grid(soup, title_suffix='', mode=95):
    for div in soup.find_all('div', class_='col-6 col-sm-4 col-md-3'):
        a_tag = div.find('a')
        h2_tag = div.find('h2')
        img_tag = div.find('img')

        if a_tag and h2_tag and img_tag:
            v_link = PHUMIK + a_tag['href']
            v_title = h2_tag.get_text(strip=True) + title_suffix
            v_image = PHUMIK + img_tag['src']
            addDir(v_title, v_link, mode, v_image)

def parse_phumik_pagination(soup, mode=91):
    pagination = soup.find('ul', class_='pagination')
    if pagination:
        for a in pagination.find_all('a', href=True):
            match = re.search(r"&page=(\d+)", a['href'])
            if match:
                page_num = match.group(1)
                addDir(f"Page {page_num}", PHUMIK + a['href'], mode, "")

def INDEX_PHUMIK(url):
    soup = BeautifulSoup(OpenSoup(url), 'html.parser')
    parse_phumik_grid(soup)
    parse_phumik_pagination(soup)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def SINDEX_PHUMIK(url):
    soup = BeautifulSoup(OpenSoup(url), 'html.parser')
    parse_phumik_grid(soup, title_suffix=' [COLOR green]PHUMIK[/COLOR]')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def EPISODE_PHUMIK(url, name):
    html = OpenURL(url)
    decoded = html.decode('utf-8', errors='ignore') if isinstance(html, bytes) else html
    soup = BeautifulSoup(decoded, 'html.parser')

    match = re.search(r'div id="player"(.+?)</script>', decoded.replace('\n', ''), re.DOTALL)
    if match and 'options.player_list' in match.group(1):
        items = re.findall(r'{\s*"file":\s*"(.+?)",\s*"title":\s*"(.+?)"', match.group(1).replace("'", '"'), re.DOTALL)
        for v_link, v_title in items:
            addLink(v_title.replace(",", ""), v_link, 4, '')


     
# Below uses mode==10		
############## KhmerAve Melkon SITE ****************** 		  
def parse_generic_grid(url, mode=200, title_suffix='', color_tag='', log_label=''):
    episode_mode = 10  

    html = OpenSoup(url)
    if isinstance(html, bytes):
        html = html.decode('utf-8', errors='ignore')
    soup = BeautifulSoup(html, 'html.parser')

    # Layout detection
    div_index = soup.find_all('div', class_="col-6 col-sm-4 thumbnail-container")
    layout_type = 'thumbnail' if div_index else 'card'

    # KhmerAvenue (Chinese layout) uses 'thumbnail-container'
    # Merlkon and Korean (KhmerAvenue Korean section) use 'card-content'
    if layout_type == 'card':
        div_index = soup.find_all('div', class_='card-content')

    for item in div_index:
        try:
            v_link = v_title = v_image = v_info = ''

            if layout_type == 'thumbnail':
                # KhmerAvenue (Chinese section)
                a_tag = item.find('a')
                h3 = item.find('h3')
                h4 = item.find('h4')
                image_div = item.find('div', style=True)

                if a_tag and h3:
                    v_link = a_tag['href']
                    v_title = h3.get_text(strip=True).replace("&#8217;", "")
                    v_info = h4.get_text(strip=True).replace("Episode", "").strip() if h4 else ""

                    style = image_div.get('style', '') if image_div else ''
                    match = re.findall(r'\((.+?)\)', style)
                    v_image = match[0] if match else ''

            else:
                # Merlkon and KhmerAvenue (Korean section)
                a_tag = item.find('a', href=True)
                h3 = item.find('h3')
                episode_tag = item.find('span', class_='card-content-episode-number')
                image_div = item.find('div', class_='card-content-image')

                if a_tag and h3:
                    v_link = a_tag['href']
                    v_title = h3.get_text(strip=True)
                    v_info = episode_tag.get_text(strip=True).replace("Ep", "").strip() if episode_tag else ""

                    style = image_div.get('style', '') if image_div else ''
                    match = re.search(r'url\((.*?)\)', style)
                    v_image = match.group(1) if match else ''

            if v_link and v_title:
                v_name = f"{v_title} {v_info}".strip()
                if title_suffix:
                    v_name += f" [COLOR {color_tag}]{title_suffix}[/COLOR]" if color_tag else f" {title_suffix}"
                addDir(v_name, v_link, episode_mode, v_image)

        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] parse_generic_grid ({log_label}) error: {e}", xbmc.LOGWARNING)

    # Pagination
    nav = soup.find('div', class_='wp-pagenavi')
    if nav:
        for a in nav.find_all('a', href=True):
            page_url = a['href']
            page_num = a.get_text(strip=True)
            addDir(f"Page {page_num}", page_url, mode, '')

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def INDEX_GENERIC(url, mode, site_name=''):
    parse_generic_grid(url, mode=mode, log_label=site_name)

def SINDEX_GENERIC(url, source_tag):
    parse_generic_grid(url, mode=10, title_suffix=source_tag, color_tag='yellow', log_label='search')

   
        
############## KHMER4HOLIDAY ****************** 
def parse_khmer4_grid(url, title_suffix='', color=''):
    html = OpenURL(url)
    soup = BeautifulSoup(html, 'html.parser')

    for a_tag in soup.find_all('a', class_='entry-image-wrap is-image'):
        v_link = a_tag.get('href')
        v_title = a_tag.get('title', 'No Title')
        if color:
            v_title += f" [COLOR {color}]{title_suffix}[/COLOR]"
        span_tag = a_tag.find('span')
        v_image = span_tag.get('data-src', '') if span_tag else ''
        addDir(v_title, v_link, 10, v_image)

    # Pagination via BeautifulSoup
    pager_div = soup.find('div', id='blog-pager')
    if pager_div:
        a_tag = pager_div.find('a', attrs={'data-load': True})
        if a_tag:
            page_url = a_tag['data-load']
            addDir('NEXT PAGE', page_url, 101, '')

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def INDEX_KHMER4(url):
    parse_khmer4_grid(url)

def SINDEX_KHMER4(url):
    parse_khmer4_grid(url, title_suffix='KHMER4', color='yellow')

           


# Use for all eposode player	mode==10
def EPISODE_PLAYERS(url, name):
    html = OpenURL(url)
    decoded = html.decode("utf-8", errors='ignore')
    soup = BeautifulSoup(decoded, 'html.parser')
    links_found = False

    # ───── About section popup ─────
    last_about_url = ADDON.getSetting("about_url")
    if last_about_url != url:
        about = soup.find('div', id='about')
        if about:
            p = about.find('p', class_='album-content-description')
            if p:
                about_text = re.sub(r'<br\s*/?>', '\n', p.decode_contents())
                about_text = re.sub(r'\s+', ' ', about_text).strip()
                try:
                    xbmcgui.Dialog().textviewer("About", about_text)
                    ADDON.setSetting("about_url", url)
                except Exception as e:
                    xbmc.log(f"[{ADDON_ID}] About popup failed: {e}", xbmc.LOGWARNING)

    # ───── Optional submitter info ─────
    submitter = ""
    sub_match = re.search(r'Submitter:\s*<b[^>]*>([^<]+)</b>', decoded, re.IGNORECASE)
    if sub_match:
        submitter = sub_match.group(1).strip()

    # ────────────── CASE 1: Table layout ──────────────
    # Used by: Video4Khmer36, older Khmer4Holiday
    table_match = re.search(r'<table[^>]+id=["\']latest-videos["\'][^>]*>(.*?)</table>', decoded, re.DOTALL)
    if table_match:
        episodes = re.findall(
            r'<td>\s*<a\s+href=["\']([^"\']+)["\'].*?>(?:<i[^>]*></i>)?\s*([^<]+)\s*</a>',
            table_match.group(1), re.DOTALL)
        if episodes:
            for v_link, v_title in reversed(episodes):
                v_title = v_title.replace("Episode", "Part").strip()
                if submitter:
                    v_title += f" [COLOR grey](by {submitter})[/COLOR]"
                addLink(v_title, v_link, 3, '')
            links_found = True

    # ────────────── CASE 2: Inline styled <a> tags ──────────────
    # Used by: some Merlkon / Khmer4 older entries
    inline_links = re.findall(
        r'<a[^>]+style=["\']margin:\s*5px\s*0;["\']\s+href=["\']([^"\']+)["\'][^>]*>([^<]+)</a>',
        decoded, re.DOTALL)
    if inline_links:
        for v_link, v_name in reversed(inline_links):
            if submitter:
                v_name += f" [COLOR grey](by {submitter})[/COLOR]"
            addLink(v_name.strip(), v_link, 3, '')
        links_found = True

    # ────────────── CASE 3: KhmerAvenue / Korean-style ──────────────
    # Used by: KhmerAvenue, some Chinese/Korean episode
    if not links_found:
        a_tags = soup.find_all('a', class_='text-decoration-none')
        if a_tags:
            for a_tag in reversed(a_tags):
                v_link = a_tag.get('href')
                contents = a_tag.contents
                v_title = contents[1].strip() if len(contents) > 1 else "Episode"
                if submitter:
                    v_title += f" [COLOR grey](by {submitter})[/COLOR]"
                addLink(v_title, v_link, 3, '')
            links_found = True

    # ────────────── CASE 4: JS-Embedded Player Lists ──────────────
    # Used by: KHMER4HOLIDAY, PHUMIK (phumikhmer2.com), etc.
    if not links_found:
        player_list = None

        # Subcase A: JSON (double quotes) — Khmer4Holiday newer embeds
        match = re.search(r"options\.player_list\s*=\s*(\[\s*{.*?}\s*])\s*;", decoded, re.DOTALL)
        if match:
            try:
                player_list = json.loads(match.group(1))
                xbmc.log(f"[{ADDON_ID}] Parsed player_list using json.loads", xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] json.loads failed: {e}", xbmc.LOGWARNING)

        # Subcase B: Python-style — older Khmer4 / PHUMIK
        if not player_list:
            match = re.search(r"options\.player_list\s*=\s*(\[\s*{.*?}\s*])\s*;", decoded.replace("null", "None"), re.DOTALL)
            if match:
                try:
                    player_list = ast.literal_eval(match.group(1))
                    xbmc.log(f"[{ADDON_ID}] Parsed player_list using ast.literal_eval", xbmc.LOGDEBUG)
                except Exception as e:
                    xbmc.log(f"[{ADDON_ID}] ast.literal_eval failed: {e}", xbmc.LOGWARNING)

        # Subcase C: Regex fallback — loose match
        if not player_list:
            fallback_items = re.findall(
                r"[{[]\s*['\"]file['\"]\s*:\s*['\"](.+?)['\"],\s*['\"]title['\"]\s*:\s*['\"](.+?)['\"]",
                decoded)
            if fallback_items:
                player_list = [{'file': f, 'title': t} for f, t in fallback_items]
                xbmc.log(f"[{ADDON_ID}] Parsed player_list using fallback regex", xbmc.LOGDEBUG)

        # Add the items
        if player_list:
            for item in reversed(player_list):
                v_link = item.get('file', '').strip()
                v_title = item.get('title', '').strip()
                if v_link and v_title:
                    if submitter:
                        v_title += f" [COLOR grey](by {submitter})[/COLOR]"
                    addLink(v_title, v_link, 4, '')
            links_found = True

    # ────────────── Final fallback ──────────────
    if not links_found:
        xbmcgui.Dialog().ok("No Episodes Found", "Sorry, no playable episodes were detected.")
        xbmc.log(f"[{ADDON_ID}] No episode links found at: {url}", xbmc.LOGWARNING)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)



# ─── XML Parser ─────────────────────────────────────
def OpenXML(Doc):
    dom = xml.dom.minidom.parseString(Doc)
    for item in dom.getElementsByTagName('item'):
        desc = item.getElementsByTagName('description')[0].firstChild.data
        src = item.getElementsByTagName('jwplayer:source')[0].getAttribute('file')
        addLink(desc.encode("utf-8"), src.encode("utf-8"), 4, "")

# ─── Video Extractor ────────────────────────────────
def VIDEOLINKS(url):
    html = OpenSoup(url)
    if isinstance(html, bytes):
        html = html.decode('utf-8', errors='ignore')

    # Try decoding embedded base64 video
    base64_match = re.search(r'Base64.decode\("(.+?)"\)', html)
    if base64_match:
        try:
            decoded = base64.b64decode(base64_match.group(1)).decode('utf-8', errors='ignore')
            iframe = re.search(r'<iframe[^>]+src="(.+?)"', decoded)
            if iframe:
                VIDEO_HOSTING(iframe.group(1))
                return
        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] Base64 decode error: {e}", xbmc.LOGWARNING)

    # Try direct patterns
    patterns = [
        r'"file":\s*"(.+?)"', r"file:\s*'(.+?)'", r'<iframe[^>]+src="(.+?)"', r'<source[^>]+src="([^"]+)"',
        r'playlist:\s*"(.+?)"', r'"file":"(.+?)"', r'<div[^>]+class="video_main"[^>]*>\s*<iframe[^>]+src="([^"]+)"',
        r"var flashvars = {file: '(.+?)'", r'swfobject\.embedSWF\("(.+?)"', r'<script>\s*vidId = \'(.+?)\';'
    ]

    for pattern in patterns:
        match = re.findall(pattern, html)
        if match:
            video = match[0]
            if 'vidId' in pattern:
                video = f"https://docs.google.com/file/d/{video}/preview"
            VIDEO_HOSTING(video)
            return

    xbmc.log(f"[{ADDON_ID}] No video link found in VIDEOLINKS", xbmc.LOGWARNING)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

# ─── InputStream Enabler ────────────────────────────
def enable_inputstream_adaptive():
    try:
        addon = xbmcaddon.Addon('inputstream.adaptive')
        if not addon.getSettingBool('enabled'):
            xbmc.log('[KDUBBED] Enabling inputstream.adaptive', xbmc.LOGINFO)
            xbmc.executebuiltin('EnableAddon(inputstream.adaptive)')
    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to enable inputstream.adaptive: {e}", xbmc.LOGWARNING)

# ─── Stream Playback ────────────────────────────────
def Playloop(VideoURL):
    print(f'PLAY VIDEO: {VideoURL}')
    enable_inputstream_adaptive()

    item = xbmcgui.ListItem(path=VideoURL)
    item.setContentLookup(False)

    if '.m3u8' in VideoURL:
        item.setMimeType('application/vnd.apple.mpegurl')
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    elif '.mpd' in VideoURL:
        item.setMimeType('application/dash+xml')
        item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    else:
        item.setMimeType('application/vnd.apple.mpegurl')
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')

    item.setProperty('inputstream', 'inputstream.adaptive')
    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)

# ─── NET Fetch ──────────────────────────────────────
def OpenNET(url):
    try:
        net = Net(cookie_file=cookiejar)
        return net.http_GET(url).content
    except Exception:
        try:
            return net.http_GET(url.encode("utf-8")).content
        except:
            xbmcgui.Dialog().ok("Connection Failed", url, "Try again later.")

# ─── Video Host Router ──────────────────────────────
def VIDEO_HOSTING(vlink):
    hosters = {
        'khmotions.com': KHMOTIONS,
        'kolabkhmer.club': KOLABKHMERS,
        'kolabkhmer.html': KHMER7,
        'dailymotion.com': DAILYMOTION,
        'estream.to': ESTREAM,
        'facebook.com': FACEBOOK,
        'fembed.com': FEMBED,
        'google.com': GOOGLE,
        'k-vid.net': KVID,
        'movie-khmer.com': MOVIEKHMER,
        'mp4upload.com': MP4UPLOAD,
        'ok.ru': OKRU,
        'openload.co': OPENLOAD,
        'rapidvideo.com': RAPIDVIDEOCOM,
        'streamango.com': STREAMANGO,
        'subkh.com': SUBKH,
        'vev.io': VEVIO,
        'vimeo.com': VIMEO,
        'vidlox.me': VIDLOX,
        'xstreamcdn.com': XSTREAMCDN,
        'youtube.com': YOUTUBE
    }

    for key, handler in hosters.items():
        if key in vlink:
            try:
                VideoURL = handler(vlink)
                if VideoURL:
                    print(f'Resolved {key}: {VideoURL}')
                    return Play_VIDEO(VideoURL)
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] {key} resolve failed: {e}", xbmc.LOGWARNING)
                break

    # fallback
    print(f'Fallback VideoURL: {vlink}')
    xbmc.executebuiltin("XBMC.Notification(Please Wait!, Khmer Dubbed is loading...)")
    return Play_VIDEO(urllib2.unquote(vlink))

# ─── Final Playback Handler ─────────────────────────
def Play_VIDEO(VideoURL):
    print(f'PLAY VIDEO: {VideoURL}')
    item = xbmcgui.ListItem(path=VideoURL)
    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)




# ─── Cookie-Aware Fetch ─────────────────────────────
def GetContent2(url, referr, cj=None):
    from io import BytesIO

    cj = cj or cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    opener.addheaders = [
        ('User-Agent', USER_AGENT),
        ('Referer', referr),
        ('Accept-Encoding', 'gzip, deflate'),
        ('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
        ('Content-Type', 'application/x-www-form-urlencoded'),
        ('Connection', 'keep-alive'),
        ('Accept-Language', 'en-us,en;q=0.5'),
        ('Pragma', 'no-cache')
    ]

    with opener.open(url) as usock:
        content = usock.read()
        if usock.info().get('Content-Encoding') == 'gzip':
            buf = BytesIO(content)
            content = gzip.GzipFile(fileobj=buf).read()
    return cj, content


# ─── Video Host Resolvers ───────────────────────────

def resolve_with_fallback(url):
    try:
        return resolveurl.resolve(url)
    except Exception:
        return None

# Map common resolvers directly
DAILYMOTION = ESTREAM = FACEBOOK = GOOGLE = MP4UPLOAD = OKRU = OPENLOAD = \
RAPIDVIDEOCOM = STREAMANGO = VEVIO = VIDLOX = XSTREAMCDN = YOUTUBE = resolve_with_fallback


def KHMOTIONS(SID):
    headers = {'User-Agent': USER_AGENT}
    req = urllib2.Request(SID, headers=headers)
    link = urllib2.urlopen(req).read().decode()
    qualities = ['720', '480', '360', '240']
    for q in qualities:
        match = re.findall(rf'file:\s*"(.+?)",.+?{q}.+?"', link, re.DOTALL)
        if match:
            return urllib.parse.unquote_plus(match[0])
    match = re.findall(r'file : "(.+?)"', link)
    return match[0] if match else None


def KOLABKHMERS(SID):
    url = urllib2.unquote(SID).replace("//", "http://")
    req = urllib2.Request(url, headers={'User-Agent': USER_AGENT})
    link = urllib2.urlopen(req).read().decode().replace('\\/', '/')
    match = re.findall(r'"file":"(.+?)"', link)
    return match[0] if match else None


def KHMER7(SID):
    media_id = re.findall(r"slug=(.+?)&", SID)[0]
    headers = {
        'Referer': 'https://www.kolabkhmer.com/kolabkhmer.html',
        'User-Agent': USER_AGENT
    }
    page = requests.get(SID, headers=headers).text
    key = re.findall(r'key: "(.+?)",', page)[0]
    data = {'key': key, 'type': 'slug', 'value': media_id, 'dataType': 'm3u8'}
    resp = requests.post("https://multi.idocdn.com/vip", data=data).text
    match = re.findall(r'"link":"(.+?)"', resp)
    return get_link(match[0], headers['Referer']) if match else None


def MOVIEKHMER(SID):
    url = 'https:' + SID if not SID.startswith('http') else SID
    headers = {'Referer': 'https://movie-khmer.com', 'User-Agent': USER_AGENT}
    page = requests.get(url, headers=headers).text
    match = re.findall(r'file:"(.+?)"', page)
    return f"{match[0]}|{urlencode(headers)}" if match else None


def FEMBED(Video_ID):
    media_id = re.findall(r"fembed.com/v/(.+)", Video_ID)[0]
    url = f'https://www.fembed.com/api/source/{media_id}'
    response = requests.post(url).text.replace('\\/', '/')
    for res in ['720p', '480p', '360p', '240p']:
        match = re.findall(rf'"file":"(.+?)".+?"{res}"', response, re.DOTALL)
        if match:
            return urllib.parse.unquote_plus(match[0])
    return None


def VIMEO(Video_ID):
    media_id = re.findall(r"vimeo.com/(?:video/)?(\d+)", Video_ID)[0]
    url = f"https://player.vimeo.com/video/{media_id}?api=1&player_id=video_player"
    referer = "http://" + Video_ID.split('/')[2]
    headers = {'Referer': referer}
    page = requests.get(url, headers=headers).text
    match = re.findall(r'"hls"[^>]*"akfire_interconnect_quic":{"url":"(.+?)"', page)
    return match[0] if match else None


def KVID(SID):
    link = OpenURL(SID).decode(errors='ignore')
    match = re.findall(r'window.location = "(.+?)"', link)
    return resolve_with_fallback(match[0]) if match else None


def SUBKH(SID):
    try:
        return resolveurl.resolve(SID)
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] SUBKH error: {e}", xbmc.LOGWARNING)
        return None


	
###################### Resolver End  ###################    

# ----- Utility Functions -----

def addLink(name, url, mode, iconimage):
    u = f"{sys.argv[0]}?url={quote_plus(url)}&mode={mode}&name={quote_plus(name)}"
    liz = xbmcgui.ListItem(label=name)
    liz.setArt({'icon': iconimage, 'poster': iconimage, 'thumb': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=liz, isFolder=False)

def addDir(name, url, mode, iconimage):
    u = f"{sys.argv[0]}?url={quote_plus(url)}&mode={mode}&name={quote_plus(name)}"
    liz = xbmcgui.ListItem(label=name)
    liz.setArt({'icon': iconimage, 'poster': iconimage, 'thumb': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=liz, isFolder=True)

def get_params():
    param = {}
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        cleanedparams = paramstring.replace('?', '')
        pairs = cleanedparams.split('&')
        for pair in pairs:
            if '=' in pair:
                key, value = pair.split('=')
                param[key] = urllib.unquote_plus(value)
    return param

# ----- Parameter Parsing -----

params = get_params()
url = params.get("url")
name = params.get("name")
mode = int(params.get("mode", -1))  # fallback/default

# ----- Routing -----

mode_dispatch = {
    -1: HOME,
    2: lambda: Playloop(url),
    3: lambda: VIDEOLINKS(url),
    4: lambda: VIDEO_HOSTING(url),
    5: SEARCH,
    6: lambda: PlayURL(url),
    10: lambda: EPISODE_PLAYERS(url, name),
    11: lambda: KHMERYV(url),
    21: lambda: INDEX_GENERIC(url, 21, 'khmeravenue'),
    22: lambda: INDEX_GENERIC(url, 22, 'merlkon'),
    23: lambda: INDEX_GENERIC(url, 23, 'korean'),
    31: lambda: INDEX_VIDEO4U(url),
    35: lambda: EPISODE_VIDEO4U(url, name),
    91: lambda: INDEX_PHUMIK(url),
    95: lambda: EPISODE_PHUMIK(url, name),
    101: lambda: INDEX_KHMER4(url),
}

# Execute matching function or fallback to HOME if missing or url is blank
if not url or mode not in mode_dispatch:
    HOME()
else:
    mode_dispatch[mode]()  # call the corresponding function

xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
