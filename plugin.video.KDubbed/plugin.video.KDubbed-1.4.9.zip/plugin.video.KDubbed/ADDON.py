# Compatibility & Imports
import sys
import os
import xml.dom.minidom
import re
import json
import gzip
import base64
import string
import requests
import time
import xml.etree.ElementTree as ET

# Kodi modules
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmc
import xbmcvfs

# External libraries
from bs4 import BeautifulSoup
import resolveurl
from urllib.parse import quote_plus, unquote_plus
from constants import khmertv


# Global cache to avoid repeated "About" dialogs or info displays
ABOUT_SHOWN_CACHE = {}

# Constants
ADDON = xbmcaddon.Addon(id='plugin.video.KDubbed')
ADDON_ID = 'plugin.video.KDubbed'
ADDON_PATH = ADDON.getAddonInfo('path')
DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')
PLUGIN_HANDLE = int(sys.argv[1])

# User agent
USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"

# Base URLs
VIDEO4KHMER = 'https://www.video4khmer36.com/'
PHUMIK = 'https://www.phumikhmer1.club/'
KHMERAVENUE = 'https://www.khmeravenue.com/'
MERLKON = 'https://www.khmerdrama.com/'
KHMER4 = 'https://www.khmer4holiday.com/'
CKCH7 ='http://www.ckh7.com/'


# Icons and fanart
IMAGE_PATH = os.path.join(ADDON_PATH, 'resources', 'images')
ICON_JOLCHET = os.path.join(IMAGE_PATH, 'icon.png')
ICON_SEARCH = os.path.join(IMAGE_PATH, 'search1.png')
ICON_KHMERTV = os.path.join(IMAGE_PATH, 'khmertv.png')
FANART = os.path.join(IMAGE_PATH, 'fanart.jpg')

# Utility Functions
def _fetch_url(url, user_agent, as_text=False, timeout=10, retries=3, delay=2):
    headers = {'User-Agent': user_agent}
    for attempt in range(1, retries + 1):
        try:
            response = requests.get(url, headers=headers, timeout=timeout)
            response.raise_for_status()
            return response.text if as_text else response.content
        except requests.exceptions.Timeout:
            xbmc.log(f"[{ADDON_ID}] Timeout (attempt {attempt}) on: {url}", xbmc.LOGWARNING)
        except requests.exceptions.RequestException as e:
            xbmc.log(f"[{ADDON_ID}] Request error (attempt {attempt}): {e}", xbmc.LOGWARNING)
        time.sleep(delay)
    xbmc.log(f"[{ADDON_ID}] Failed to fetch after {retries} attempts: {url}", xbmc.LOGERROR)
    return '' if as_text else b''

def OpenURL(url, timeout=10, retries=3, delay=2):
    return _fetch_url(url, USER_AGENT, as_text=False, timeout=timeout, retries=retries, delay=delay)

def OpenSoup(url, timeout=10, retries=3, delay=2):
    return _fetch_url(url, USER_AGENT, as_text=True, timeout=timeout, retries=retries, delay=delay)


# Virtual keyboard
def GetInput(message, heading, is_hidden=False):
    keyboard = xbmc.Keyboard("", message, is_hidden)
    keyboard.setHeading(heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return keyboard.getText()
    return ""

# Main Menu
def HOME():
    addDir("[COLOR yellow][B][I]SEARCH[/I][/B][/COLOR]", MERLKON, 5, ICON_SEARCH)
    addDir("Khmer Live TV", khmertv, 1101, ICON_KHMERTV)

    # KHMERAVENUE
    KHMERAVENUE_LOGO = 'https://www.khmeravenue.com/wp-content/themes/avenue/img/logo.png'
    addDir('============= [COLOR red] KHMERAVENUE [/COLOR] =============', "", 21, KHMERAVENUE_LOGO)
    addDir('Chinese', f'{KHMERAVENUE}album/', 21, KHMERAVENUE_LOGO)
    addDir('Korean', f'{KHMERAVENUE}country/korea/', 23, KHMERAVENUE_LOGO)

    # MERLKON categories
    MERLKON_LOGO = 'https://www.khmerdrama.com/wp-content/themes/avenue/img/logo.png'
    addDir('Thai HD', f'{MERLKON}country/thailand/', 22, MERLKON_LOGO)
    addDir('Thai Boran', f'{MERLKON}genre/thai-boran/', 22, MERLKON_LOGO)
    addDir('Thai Horror', f'{MERLKON}genre/horror/', 22, MERLKON_LOGO)
    addDir('Thai Mayura', f'{MERLKON}dubbed/mayura/', 22, MERLKON_LOGO)
    addDir('Thai KM', f'{MERLKON}dubbed/km/', 22, MERLKON_LOGO)
    addDir('Indian', f'{MERLKON}country/India/', 22, MERLKON_LOGO)
    addDir('Philippines', f'{MERLKON}country/philippines/', 22, MERLKON_LOGO)
    addDir('Cambodia', f'{MERLKON}country/cambodia/', 22, MERLKON_LOGO)
    addDir('Kon', f'{MERLKON}albumcategory/kon/', 22, MERLKON_LOGO)

    # VIDEO4KHMER
    V4K_LOGO = 'https://www.video4khmer36.com/templates/pkakrovan/images/all/logo.png'
    addDir('============= [COLOR red] VIDEO4KHMER [/COLOR] =============', "", 31, V4K_LOGO)
    addDir('Cambodia', f'{VIDEO4KHMER}khmer-movie-category/khmer-drama-watch-online-free-catalogue-504-page-1.html', 31, V4K_LOGO)
    addDir('Chinese Aired', f'{VIDEO4KHMER}khmer-movie-category/chinese-series-drama-to-be-continued-catalogue-2673-page-1.html', 31, V4K_LOGO)
    addDir('Chinese Completed', f'{VIDEO4KHMER}khmer-movie-category/chinese-series-drama-watch-online-free-catalogue-506-page-1.html', 31, V4K_LOGO)
    addDir('Thai Aired', f'{VIDEO4KHMER}khmer-movie-category/thai-lakorn-drama-to-be-continued-catalogue-2674-page-1.html', 31, V4K_LOGO)
    addDir('Thai Completed', f'{VIDEO4KHMER}khmer-movie-category/thai-lakorn-drama-watch-online-free-catalogue-537-page-1.html', 31, V4K_LOGO)
    addDir('Korean Aired', f'{VIDEO4KHMER}khmer-movie-category/korean-drama-to-be-continued-catalogue-508-page-1.html', 31, V4K_LOGO)
    addDir('Korean Completed', f'{VIDEO4KHMER}khmer-movie-category/korean-drama-watch-online-free-catalogue-507-page-1.html', 31, V4K_LOGO)

    # KHMER4HOLIDAY
    KHMER4_LOGO = 'https://1.bp.blogspot.com/-9Y8PknwGtEE/YVp_qF4rR-I/AAAAAAAABAg/k4IED_8_o34L--XjAoMYZ6SwCKQgMZJkwCLcBGAsYHQ/s754/Khmer4Holiday.png'
    addDir('============= [COLOR red] KHMER4HOLIDAY [/COLOR] =============', "", 101, KHMER4_LOGO)
    addDir('Khmer', f'{KHMER4}search/label/Khmer%20Drama?&max-results=24', 101, KHMER4_LOGO)
    addDir('Thai', f'{KHMER4}search/label/Thai%20Drama?&max-results=24', 101, KHMER4_LOGO)
    addDir('Chinese', f'{KHMER4}search/label/Chines%20Drama?&max-results=24', 101, KHMER4_LOGO)
    addDir('Korean', f'{KHMER4}search/label/Korea%20Drama?&max-results=24', 101, KHMER4_LOGO)
    addDir('Thai4', f'{PHUMIK}search/label/Thai?&max-results=24', 91, 'https://phumikhmer2.com/home/img/logo.png')

    # CKCH7
    CKCH7_LOGO = 'https://www.ckh7.com/uploads/custom-logo.png'
    addDir('============= [COLOR red] CKCH7 [/COLOR] =============', "", 41, CKCH7_LOGO)
    addDir('Khmer', f'{CKCH7}category.php?cat=khmer', 41, CKCH7_LOGO)
    addDir('Thai', f'{CKCH7}category.php?cat=thai', 41, CKCH7_LOGO)
    addDir('Chinese', f'{CKCH7}category.php?cat=chinese', 41, CKCH7_LOGO)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

# Search function    
def SEARCH():
    sources = [
        ('KhmerAvenue', 201),
        ('Merlkon', 202),
        ('Khmer4Holiday', 203),
        ('PhumiKhmer', 204),
        ('Video4Khmer36', 205),
        ('CKCH7', 206)        
    ]
    dialog = xbmcgui.Dialog()
    choice = dialog.select('Search From:', [s[0] for s in sources])
    if choice == -1:
        return

    keyb = xbmc.Keyboard('', 'Enter Search Text')
    keyb.doModal()
    if not keyb.isConfirmed():
        return

    search_text = keyb.getText()
    encoded_text = quote_plus(search_text)

    source = sources[choice][0]

    if source == 'KhmerAvenue':
        SINDEX_GENERIC(f'{KHMERAVENUE}?s={encoded_text}', '[COLOR yellow]KHMERAVE[/COLOR]')
    elif source == 'Merlkon':
        SINDEX_GENERIC(f'{MERLKON}?s={encoded_text}', '[COLOR cyan]MELKON[/COLOR]')
    elif source == 'Khmer4Holiday':
        SINDEX_KHMER4(f'{KHMER4}search?q={encoded_text}')
    elif source == 'PhumiKhmer':
        SINDEX_PHUMIK(f'{PHUMIK}search?q={encoded_text}')
    elif source == 'Video4Khmer36':
        SEARCH_VIDEO4U(search_text)
    elif source == 'CKCH7':
        SINDEX_CKCH7(f'{CKCH7}search.php?keywords={encoded_text}')       

# KhmerTV
def KHMER_LIVETV():
    try:
        decoded_url = base64.b64decode(khmertv).decode("utf-8")
        xml_data = OpenURL(decoded_url)

        if isinstance(xml_data, bytes):
            xml_data = xml_data.decode("utf-8", errors="ignore")

        # Clean up indentation and empty lines
        xml_data = "\n".join(
            line.strip() for line in xml_data.splitlines() if line.strip()
        )

        # Fix unescaped & characters that are not part of valid entities
        xml_data = re.sub(r'&(?!amp;|lt;|gt;|apos;|quot;)', '&amp;', xml_data)

        root = ET.fromstring(xml_data)
        items = root.findall(".//channel/item") or root.findall(".//item")

        if not items:
            raise Exception("No <item> found in <channel> or root")

        xbmc.log(f"[{ADDON_ID}] Loaded XML with {len(items)} channels", xbmc.LOGINFO)

        for item in items:
            title = item.findtext("title", default="No Title").strip()
            url = item.findtext("link", default="").strip()
            icon = item.findtext("thumbnail", default="").strip()
            resolve = item.findtext("resolve", default="false").strip().lower() == "true"

            if not url:
                xbmc.log(f"[{ADDON_ID}] Skipping item with missing URL: {title}", xbmc.LOGWARNING)
                continue

            if not icon:
                icon = ICON_KHMERTV  # fallback icon

            li = xbmcgui.ListItem(label=title)
            li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
            li.setInfo('video', {'title': title})
            li.setProperty('IsPlayable', 'true' if resolve else 'false')

            plugin_url = f"{sys.argv[0]}?mode={'2' if resolve else '4'}&url={quote_plus(url)}"

            xbmc.log(f"[{ADDON_ID}] Adding: {title} ({'Play' if resolve else 'Folder'})", xbmc.LOGINFO)

            xbmcplugin.addDirectoryItem(
                handle=PLUGIN_HANDLE,
                url=plugin_url,
                listitem=li,
                isFolder=not resolve
            )

        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Failed to load KHMER_LIVETV_XML: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", "Failed to load Live TV feed.")


############## VIDEO4KHMER ****************** 
def INDEX_VIDEO4U(url):
    html = OpenSoup(url)
    soup = BeautifulSoup(html, 'html.parser')

    for div in soup.find_all('div', class_='cover-thumb'):
        a_tag = div.find('a')
        style = div.get('style', '')
        v_link = a_tag['href']
        v_title = a_tag.get('title', 'No Title')
        v_image = style.replace('background-image: url(', '').replace(')', '')
        addDir(v_title, v_link, 35, v_image)

    # Handle pagination
    pagination = soup.find('ul', class_='pagination')
    if pagination:
        for a in pagination.find_all('a'):
            page_url = a.get('href')
            page_num = a.decode_contents().strip()
            page_num = re.sub(r'<i[^>]*></i>', '', page_num)  
            addDir(f"Page {page_num}", page_url, 31, "")

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
    
def SEARCH_VIDEO4U(search_term):
    search_url = f"https://www.video4khmer36.com/search.php?keywords={quote_plus(search_term)}&page=1"
    html = OpenSoup(search_url)
    soup = BeautifulSoup(html, 'html.parser')

    for div in soup.find_all('div', class_='cover-thumb'):
        a_tag = div.find('a')
        style = div.get('style', '')
        v_link = a_tag['href']
        v_title = a_tag.get('title', 'No Title')
        v_image = style.replace('background-image: url(', '').replace(')', '')
        addDir(f"{v_title} [COLOR red]VIDEO4KHMER[/COLOR]", v_link, 35, v_image)
  

def EPISODE_VIDEO4U(url, name):
    html = OpenSoup(url)
    decoded = html.decode("utf-8", errors="ignore") if isinstance(html, bytes) else html

    # --- Show "Summary" popup only once per URL ---
    last_summary_url = ADDON.getSetting("summary_url")
    if last_summary_url != url:
        summary_match = re.search(
            r'<h2 class="h3">Summary:</h2>\s*<p class="justified-text">(.*?)</p>',
            decoded,
            re.DOTALL | re.IGNORECASE
        )
        if summary_match:
            summary = summary_match.group(1)
            summary = re.sub(r'<br\s*/?>', '\n', summary)
            summary = re.sub(r'\s+', ' ', summary).strip()
            try:
                xbmcgui.Dialog().textviewer("Summary", summary)
                ADDON.setSetting("summary_url", url)
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] Failed to show Summary popup: {e}", xbmc.LOGWARNING)

    soup = BeautifulSoup(decoded, 'html.parser')
    addLink(name, url, 3, '')

    for a_tag in soup.find_all('a', class_='text-decoration-none'):
        v_link = a_tag.get('href')
        try:
            v_title = a_tag.contents[1].strip() if len(a_tag.contents) > 1 else "Episode"
        except Exception:
            v_title = "Episode"
        addLink(v_title, v_link, 3, '')

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)



# Below uses mode==10	
############## ckch7 ****************** 
def INDEX_CKCH7(url):
    html = OpenSoup(url)
    try:
        html = html.encode("UTF-8")
    except:
        pass

    soup = BeautifulSoup(html.decode("utf-8", errors="ignore"), "html.parser")

    # ------- 1 · Video cards -------------------------------------------------
    cards = soup.find_all("div",  class_="col-xs-6 col-sm-6 col-md-3")
    for card in cards:
        a_tag  = card.find("a", href=True)
        img_tag = card.find("img")

        if not (a_tag and img_tag):
            continue

        v_link  = a_tag["href"].strip()
        v_title = img_tag.get("alt", "No Title").strip()
        v_image = img_tag.get("data-echo", "") or img_tag.get("src", "")
        addDir(v_title, v_link, 10, v_image)

    # ------- 2 · Pagination --------------------------------------------------
    pages = re.findall(
        r'<ul class="pagination[^"]*">(.+?)</ul>',
        html.decode("utf-8", errors="ignore"),
        re.DOTALL
    )

    if pages:
        page_links = re.findall(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', pages[0])
        for href, label in page_links:
            label = label.strip().replace("&laquo;", "<").replace("&raquo;", ">")
            if not href or not label:
                continue
            full_url = CKCH7 + href.lstrip("/")
            addDir("Page " + label, full_url, 41, "")

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def SINDEX_CKCH7(url): 
    html = OpenSoup(url)
    try:
        html = html.encode("UTF-8")
    except:
        pass

    soup = BeautifulSoup(html.decode("utf-8", errors="ignore"), "html.parser")
    cards = soup.find_all("div",  class_="col-xs-6 col-sm-6 col-md-3")
    for card in cards:
        a_tag  = card.find("a", href=True)
        img_tag = card.find("img")

        if not (a_tag and img_tag):
            continue

        v_link  = a_tag["href"].strip()
        v_title = img_tag.get("alt", "No Title").strip()
        v_image = img_tag.get("data-echo", "") or img_tag.get("src", "")
        addDir(f"{v_title} [COLOR green]CKCH7[/COLOR]", v_link, 10, v_image) 



############## phumikhmer2 ****************** 
def INDEX_PHUMIK(url):
    html = OpenSoup(url)
    try:
        html = html.encode('utf-8')
    except Exception:
        pass

    soup = BeautifulSoup(html.decode('utf-8', errors='ignore'), 'html.parser')

    # ------- 1 · Video cards -------------------------------------------------
    cards = soup.find_all('div', class_='post-filter-inside-wrap')
    for wrap in cards:
        a_tag  = wrap.find('a', class_='post-filter-link')          # Detail link
        h2_tag = wrap.find('h2', class_=re.compile(r'entry-title')) # Title
        img_tag = wrap.find('img', class_='snip-thumbnail')         # Thumbnail
        if not (a_tag and h2_tag and img_tag):
            continue

        v_link  = a_tag['href']
        v_title = h2_tag.get_text(strip=True)
        v_image = img_tag.get('data-src') or img_tag.get('src', '')
        v_image = re.sub(r'/w\d+-h\d+[^/]+/', '/s1600/', v_image)   # Fix: Replace low-res proxy path with high-res original
        addDir(v_title, v_link, 10, v_image)

    # ------- 2 · Pagination --------------------------------------------------
    pages = re.findall(
        r"<a[^>]*class='blog-pager-older-link'[^>]*href='([^']+)'",
        html.decode('utf-8', errors='ignore')
    )
    for page_url in pages:
        addDir('NEXT PAGE', page_url, 91, "")

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def SINDEX_PHUMIK(url):
    html = OpenSoup(url)
    try:
        html = html.encode('utf-8')
    except Exception:
        pass

    soup = BeautifulSoup(html.decode('utf-8', errors='ignore'), 'html.parser')
    cards = soup.find_all('div', class_='post-filter-inside-wrap')
    for wrap in cards:
        a_tag  = wrap.find('a', class_='post-filter-link')          # Detail link
        h2_tag = wrap.find('h2', class_=re.compile(r'entry-title')) # Title
        img_tag = wrap.find('img', class_='snip-thumbnail')         # Thumbnail
        if not (a_tag and h2_tag and img_tag):
            continue

        v_link  = a_tag['href']
        v_title = h2_tag.get_text(strip=True)
        v_image = img_tag.get('data-src') or img_tag.get('src', '')
        v_image = re.sub(r'/w\d+-h\d+[^/]+/', '/s1600/', v_image)   # Fix: Replace low-res proxy path with high-res original
        addDir(f"{v_title} [COLOR green]PHUMIK[/COLOR]", v_link, 10, v_image) 
        
	
############## KhmerAve Melkon SITE ****************** 		  
def INDEX_GENERIC(url, mode, site_name=''):
    html = OpenSoup(url)
    if isinstance(html, bytes):
        html = html.decode('utf-8', errors='ignore')

    soup = BeautifulSoup(html, 'html.parser')

    # Detect layout type
    # KhmerAvenue (Chinese) uses 'thumbnail-container'
    # Melkon and KhmerAvenue (Korean) use 'card-content'
    div_index = soup.find_all('div', class_="col-6 col-sm-4 thumbnail-container")
    layout_type = 'thumbnail' if div_index else 'card'
    if layout_type == 'card':
        div_index = soup.find_all('div', class_='card-content')

    for item in div_index:
        try:
            if layout_type == 'thumbnail':
                # ------- KhmerAvenue (Chinese layout) -------
                a_tag = item.find('a')
                h3_tag = item.find('h3')
                h4_tag = item.find('h4')  # optional episode number
                image_div = item.find('div', style=True)

                v_link = a_tag['href']
                v_title = h3_tag.get_text(strip=True).replace("&#8217;", "")
                v_info = h4_tag.get_text(strip=True).replace("Episode", "").strip() if h4_tag else ""
                v_name = f"{v_title} {v_info}".strip()

                # Extract image from inline CSS
                v_image = ""
                if image_div:
                    style = image_div.get('style', '')
                    match = re.findall(r'\((.+?)\)', style)
                    if match:
                        v_image = match[0]

            else:
                # ------- Melkon or KhmerAvenue (Korean card layout) -------
                a_tag = item.find('a', href=True)
                title_tag = item.find('h3')
                episode_tag = item.find('span', class_='card-content-episode-number')
                image_div = item.find('div', class_='card-content-image')

                v_link = a_tag['href'] if a_tag else ""
                v_title = title_tag.get_text(strip=True) if title_tag else ""
                v_info = episode_tag.get_text(strip=True).replace("Ep", "").strip() if episode_tag else ""
                v_name = f"{v_title} {v_info}".strip()

                # Extract image from background style
                v_image = ""
                if image_div and 'style' in image_div.attrs:
                    style = image_div['style']
                    match = re.search(r'url\((.*?)\)', style)
                    if match:
                        v_image = match.group(1)

            if v_link and v_title:
                addDir(v_name, v_link, 10, v_image)

        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] INDEX_GENERIC ({site_name}) item error: {str(e)}", xbmc.LOGWARNING)

    # -------- Pagination --------
    match = re.search(r"<div class='wp-pagenavi' role='navigation'>\n(.+?)\n</div>", html)
    if match:
        pages = re.findall(r'<a class=".+?" title=".+?" href="(.+?)">(.+?)</a>', match.group(1))
        for page_url, page_num in pages:
            addDir(f"Page {page_num}", page_url, mode, "")


def SINDEX_GENERIC(url, source_tag):
    html = OpenSoup(url)
    if isinstance(html, bytes):
        html = html.decode('utf-8', errors='ignore')

    soup = BeautifulSoup(html, 'html.parser')

    # Detect layout type
    div_index = soup.find_all('div', class_="col-6 col-sm-4 thumbnail-container")
    layout_type = 'thumbnail' if div_index else 'card'
    if layout_type == 'card':
        div_index = soup.find_all('div', class_='card-content')

    for item in div_index:
        try:
            if layout_type == 'thumbnail':
                # KhmerAvenue style (thumbnail)
                a_tag = item.find('a')
                h3_tag = item.find('h3')
                h4_tag = item.find('h4')
                image_div = item.find('div', style=True)

                v_link = a_tag['href']
                v_title = h3_tag.get_text(strip=True).replace("&#8217;", "")
                v_info = h4_tag.get_text(strip=True).replace("Episode", "").strip() if h4_tag else ""
                v_name = f"{v_title} {v_info}".strip()

                v_image = ""
                if image_div:
                    style = image_div.get('style', '')
                    match = re.findall(r'\((.+?)\)', style)
                    if match:
                        v_image = match[0]
            else:
                # Melkon / Korean style (card)
                a_tag = item.find('a', href=True)
                title_tag = item.find('h3')
                episode_tag = item.find('span', class_='card-content-episode-number')
                image_div = item.find('div', class_='card-content-image')

                v_link = a_tag['href'] if a_tag else ""
                v_title = title_tag.get_text(strip=True) if title_tag else ""
                v_info = episode_tag.get_text(strip=True).replace("Ep", "").strip() if episode_tag else ""
                v_name = f"{v_title} {v_info}".strip()

                v_image = ""
                if image_div and 'style' in image_div.attrs:
                    style = image_div['style']
                    match = re.search(r'url\((.*?)\)', style)
                    if match:
                        v_image = match.group(1)

            if v_link and v_title:
                addDir(f"{v_name} {source_tag}", v_link, 10, v_image)

        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] SINDEX_GENERIC error: {str(e)}", xbmc.LOGWARNING)

        
############## KHMER4HOLIDAY ****************** 
def INDEX_KHMER4(url):
    html = OpenSoup(url)
    try:
        html = html.encode("UTF-8")
    except:
        pass

    soup = BeautifulSoup(html.decode('utf-8', errors='ignore'), 'html.parser')
    video_list = soup.find_all('a', class_='entry-image-wrap is-image')

    for a_tag in video_list:
        v_link = a_tag.get('href')
        v_title = a_tag.get('title', 'No Title')
        span_tag = a_tag.find('span')
        v_image = span_tag.get('data-src', '') if span_tag else ''
        addDir(v_title, v_link, 10, v_image)

    # Pagination
    pages = re.findall(
        r"<div class='blog-pager' id='blog-pager'>\s*<a class='blog-pager-older-link load-more btn' data-load='([^']+)'",
        html.decode('utf-8', errors='ignore')
    )
    for page_url in pages:
        addDir('NEXT PAGE', page_url, 101, "")

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def SINDEX_KHMER4(url):
    html = OpenSoup(url)
    try:
        html = html.encode("UTF-8")
    except:
        pass

    soup = BeautifulSoup(html.decode('utf-8', errors='ignore'), 'html.parser')
    video_list = soup.find_all('a', class_='entry-image-wrap is-image')

    for a_tag in video_list:
        v_link = a_tag.get('href')
        v_title = a_tag.get('title', 'No Title')
        span_tag = a_tag.find('span')
        v_image = span_tag.get('data-src', '') if span_tag else ''
        addDir(f"{v_title} [COLOR yellow]KHMER4[/COLOR]", v_link, 10, v_image)         


# Use for all eposode player	mode==10
def EPISODE_PLAYERS(url, name):
    html = OpenURL(url)
    decoded = html.decode("utf-8")
    links_found = False

    last_about_url = ADDON.getSetting("about_url")
    if last_about_url != url:
        about_match = re.search(
            r'<div[^>]+id=["\']about["\'][^>]*>.*?<p[^>]*class=["\']album-content-description["\'][^>]*>(.*?)</p>',
            decoded,
            re.DOTALL | re.IGNORECASE
        )
        if about_match:
            about_text = about_match.group(1)
            about_text = re.sub(r'<br\s*/?>', '\n', about_text)
            about_text = re.sub(r'\s+', ' ', about_text).strip()
            try:
                xbmcgui.Dialog().textviewer("About", about_text)
                ADDON.setSetting("about_url", url)  # mark as shown
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] Failed to show About popup: {e}", xbmc.LOGWARNING)

    # --- Extract submitter name ---
    submitter = ""
    submitter_match = re.search(r'Submitter:\s*<b[^>]*>([^<]+)</b>', decoded, re.IGNORECASE)
    if submitter_match:
        submitter = submitter_match.group(1).strip()

    # --- Case 1: Table-based episodes ---
    table_match = re.search(r'<table id="latest-videos"[^>]*>(.*?)</table>', decoded, re.DOTALL)
    episode_table = table_match.group(1) if table_match else ""

    match = re.findall(
        r'<td>\s*<a href="([^"]+)">\s*(?:<i[^>]*></i>)?\s*([^<]+)\s*</a>',
        episode_table
    )
    if match:
        for v_link, v_title in reversed(match):
            v_title = v_title.replace("Episode", "Part").strip()
            if submitter:
                v_title += f" [COLOR grey](by {submitter})[/COLOR]"
            addLink(v_title, v_link, 3, '')
        links_found = True

    # JS-style embed player list (Used by: Khmer4Holiday, PHUMIK)
    if not links_found:
        player_list = None

        # JSON format: JavaScript object
        match = re.search(r"options\.player_list\s*=\s*(\[\s*{.*?}\s*])\s*;", decoded, re.DOTALL)
        if match:
            try:
                player_list = json.loads(match.group(1))
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] json.loads failed: {e}", xbmc.LOGWARNING)

        # Python literal format (older PHP)
        if not player_list:
            match = re.search(r"options\.player_list\s*=\s*(\[\s*{.*?}\s*])\s*;", decoded.replace("null", "None"), re.DOTALL)
            if match:
                try:
                    player_list = ast.literal_eval(match.group(1))
                except Exception as e:
                    xbmc.log(f"[{ADDON_ID}] ast.literal_eval failed: {e}", xbmc.LOGWARNING)

        # Regex fallback for generic matches
        if not player_list:
            fallback_items = re.findall(
                r"[{[]\s*['\"]file['\"]\s*:\s*['\"](.+?)['\"],\s*['\"]title['\"]\s*:\s*['\"](.+?)['\"]", decoded)
            if fallback_items:
                player_list = [{'file': f, 'title': t} for f, t in fallback_items]

        # Add extracted links
        if player_list:
            for item in reversed(player_list):
                v_link = item.get('file', '').strip()
                v_title = item.get('title', '').strip()                 
                v_title = re.sub(r'^([\w]+\.)[^–]*?&#8211;\s*', r'\1 ', v_title) # Remove Thai part and keep the episode number (like "01." or "30E.") 
                v_title = re.sub(r'&#60\d{2,3};', '', v_title) # Khmer4Holiday remove special char, same as above
                if v_link and v_title:
                    if submitter:
                        v_title += f" [COLOR grey](by {submitter})[/COLOR]"
                    addLink(v_title, v_link, 4, '')
            links_found = True

    # Final fallback
    if not links_found:
        xbmcgui.Dialog().ok("No Episodes Found", "Sorry, no playable episodes were detected.")
        xbmc.log(f"[{ADDON_ID}] No episode links found at: {url}", xbmc.LOGWARNING)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def VIDEOLINKS(url):
    link = OpenSoup(url)

    # Ensure 'link' is a string
    if isinstance(link, bytes):
        link = link.decode('utf-8', errors='ignore')

    # Check for embedded base64 video
    base64_matches = re.findall(r'Base64.decode\("(.+?)"\)', link)
    if base64_matches:
        try:
            decoded = base64.b64decode(base64_matches[0]).decode('utf-8', errors='ignore')
            iframe = re.findall(r'<iframe[^>]+src="(.+?)"', decoded)
            if iframe:
                VIDEO_HOSTING(iframe[0])
                return
        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] Base64 decode failed: {e}", xbmc.LOGWARNING)

    # Try various direct video URL patterns
    patterns = [
        r'[\'"]?file[\'"]?\s*:\s*[\'"]([^\'"]+)[\'"]',
        r'<iframe src="(.+?)" class="video allowfullscreen="true">',
        r'<iframe frameborder="0" [^>]*src="(.+?)">',
        r'<IFRAME SRC="(.+?)" [^>]*',
        r'<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>',
        r"var flashvars = {file: '(.+?)',",
        r'swfobject\.embedSWF\("(.+?)",',
        r'src="(.+?)" allow="autoplay"',
        r'<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>',
        r'<source [^>]*src="([^"]+?)"',
        r'playlist: "(.+?)"',
        r'<!\[CDATA\[(.*?)\]\]></tvurl>'
    ]

    for pattern in patterns:
        match = re.findall(pattern, link)
        if match:
            VIDEO_HOSTING(match[0])
            return

    xbmc.log(f"[{ADDON_ID}] No video URL found in VIDEOLINKS()", xbmc.LOGWARNING)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def enable_inputstream_adaptive():
    try:
        # Install if missing
        if not xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            xbmc.executebuiltin('InstallAddon(inputstream.adaptive)')
        # Enable if disabled
        if not xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.adaptive)'):
            xbmc.executebuiltin('EnableAddon(inputstream.adaptive)')
    except Exception as e:
        xbmc.log(f'[KDUBBED] inputstream.adaptive not available: {e}', xbmc.LOGWARNING)


def Playloop(VideoURL):
    print(f'PLAY VIDEO: {VideoURL}')

    # Use FFmpeg for MSJTV: no inputstream.adaptive, just pass all headers via URL
    VideoURL += (
        '|verifypeer=false&'
        'user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/90 Safari/537.36&'
        'referer=https://live-ali7.tv360.metfone.com.kh/'
    )

    item = xbmcgui.ListItem(path=VideoURL)
    item.setMimeType('application/vnd.apple.mpegurl')  # Optional but helps HLS detection
    item.setContentLookup(False)

    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)

    

def VIDEO_HOSTING(vlink):
    if 'ok.ru' in vlink or 'youtube.com' in vlink:
        try:
            VideoURL = resolveurl.resolve(vlink)
            print(f'VideoURL: {VideoURL}')
            Play_VIDEO(VideoURL)
            return
        except Exception as e:
            print(f"Failed to resolve with resolveurl: {e}")

    print(f'Fallback VideoURL: {vlink}')
    xbmc.executebuiltin("XBMC.Notification(Please Wait!, KhmerDubbed is loading...)")
    Play_VIDEO(vlink)

def Play_VIDEO(VideoURL):
    print(f'PLAY VIDEO: {VideoURL}')
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)


# ----- Utility Functions -----

def addLink(name, url, mode, iconimage):
    u = f"{sys.argv[0]}?url={quote_plus(url)}&mode={mode}&name={quote_plus(name)}"
    liz = xbmcgui.ListItem(label=name)
    liz.setArt({'icon': iconimage, 'poster': iconimage, 'thumb': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    liz.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=liz, isFolder=False)

def addDir(name, url, mode, iconimage):
    u = f"{sys.argv[0]}?url={quote_plus(url)}&mode={mode}&name={quote_plus(name)}"
    liz = xbmcgui.ListItem(label=name)
    liz.setArt({'icon': iconimage, 'poster': iconimage, 'thumb': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=liz, isFolder=True)

def get_params():
    param = {}
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        cleanedparams = paramstring.replace('?', '')
        pairs = cleanedparams.split('&')
        for pair in pairs:
            if '=' in pair:
                key, value = pair.split('=', 1)  # safer split
                param[key] = unquote_plus(value)
    return param

# ----- Parameter Parsing -----

params = get_params()
url = params.get("url")
name = params.get("name")
mode = int(params.get("mode", -1))  # fallback/default

# ----- Routing -----

if mode == -1 or not url:
    HOME()
elif mode == 2:
    Playloop(url)
elif mode == 3:
    VIDEOLINKS(url)
elif mode == 4:
    VIDEO_HOSTING(url)
elif mode == 5:
    SEARCH()  
elif mode == 10:
    EPISODE_PLAYERS(url, name)
elif mode == 21:
    INDEX_GENERIC(url, 21, 'khmeravenue')
elif mode == 22:
    INDEX_GENERIC(url, 22, 'merlkon')
elif mode == 23:
    INDEX_GENERIC(url, 23, 'korean')
elif mode == 31:
    INDEX_VIDEO4U(url)
elif mode == 35:
    EPISODE_VIDEO4U(url, name)  
elif mode == 41:
    INDEX_CKCH7(url)    
elif mode == 91:
    INDEX_PHUMIK(url)
elif mode == 101:
    INDEX_KHMER4(url)     
elif mode == 1101:
    KHMER_LIVETV()    

xbmcplugin.endOfDirectory(PLUGIN_HANDLE)