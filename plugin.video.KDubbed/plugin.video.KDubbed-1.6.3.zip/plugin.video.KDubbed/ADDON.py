# ── Compatibility & Imports ─────────────────────────────────────
import sys
import os
import re
import ast
import json
import gzip
import time
import base64
import string
import requests
import xml.dom.minidom
import xml.etree.ElementTree as ET

# ── Kodi Modules ────────────────────────────────────────────────
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# ── External Libraries ──────────────────────────────────────────
import resolveurl
from bs4 import BeautifulSoup
from urllib.parse import quote_plus, unquote_plus, urljoin
from html import unescape as html_unescape
from resources.lib.constants import khmertv

# ── Global Cache ────────────────────────────────────────────────
ABOUT_SHOWN_CACHE = {}  # prevent repeated "About" dialogs

# ── Add-on Constants ────────────────────────────────────────────
ADDON_ID = 'plugin.video.KDubbed'
ADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_PATH = ADDON.getAddonInfo('path')
DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')
PLUGIN_HANDLE = int(sys.argv[1])

# ── User Agent ──────────────────────────────────────────────────
USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"

# ── Base URLs ───────────────────────────────────────────────────
VIDEO4KHMER  = 'https://www.video4khmer36.com/'
PHUMIK       = 'https://www.phumikhmer1.club/'
KHMERAVENUE  = 'https://www.khmeravenue.com/'
MERLKON      = 'https://www.khmerdrama.com/'
CKCH7        = 'http://www.ckh7.com/'
SUNDAY       = 'https://www.sundaydrama.com/'

# ── Icons and Fanart ────────────────────────────────────────────
IMAGE_PATH     = os.path.join(ADDON_PATH, 'resources', 'images')
ICON_JOLCHET   = os.path.join(IMAGE_PATH, 'icon.png')
ICON_SEARCH    = os.path.join(IMAGE_PATH, 'search1.png')
ICON_KHMERTV   = os.path.join(IMAGE_PATH, 'khmertv.png')
FANART         = os.path.join(IMAGE_PATH, 'fanart.jpg')
ICON_KHMERAVE  = "https://www.khmeravenue.com/wp-content/themes/avenue/img/logo.png"
ICON_MERLKON   = "https://www.khmerdrama.com/wp-content/themes/avenue/img/logo.png"

# ── Utility Functions ───────────────────────────────────────────
def _fetch_url(url, user_agent, as_text=False, timeout=10, retries=3, delay=2):
    headers = {'User-Agent': user_agent}
    for attempt in range(1, retries + 1):
        try:
            response = requests.get(url, headers=headers, timeout=timeout)
            response.raise_for_status()
            return response.text if as_text else response.content
        except requests.exceptions.Timeout:
            xbmc.log(f"[{ADDON_ID}] Timeout (attempt {attempt}) on: {url}", xbmc.LOGWARNING)
        except requests.exceptions.RequestException as e:
            xbmc.log(f"[{ADDON_ID}] Request error (attempt {attempt}): {e}", xbmc.LOGWARNING)
        time.sleep(delay)
    xbmc.log(f"[{ADDON_ID}] Failed to fetch after {retries} attempts: {url}", xbmc.LOGERROR)
    return '' if as_text else b''

def OpenURL(url, timeout=10, retries=3, delay=2, headers=None, as_text=False):
    final_headers = {'User-Agent': USER_AGENT}
    if headers:
        final_headers.update(headers)
    for attempt in range(1, retries + 1):
        try:
            response = requests.get(url, headers=final_headers, timeout=timeout)
            response.raise_for_status()
            return response.text if as_text else response.content
        except Exception as e:
            if attempt >= retries:
                raise e
            time.sleep(delay)

def OpenSoup(url, return_html=False, **kwargs):
    html = OpenURL(url, as_text=True, **kwargs)
    if not html:
        raise Exception(f"Empty or failed response from URL: {url}")
    soup = BeautifulSoup(html, "html.parser")
    return (soup, html) if return_html else soup


# ── Virtual Keyboard Input ──────────────────────────────────────
def GetInput(message, heading, is_hidden=False):
    keyboard = xbmc.Keyboard('', message, is_hidden)
    keyboard.setHeading(heading)
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else ""


# Main Menu
def HOME():
    addDir("[COLOR yellow][B][I]SEARCH[/I][/B][/COLOR]", MERLKON, "search", ICON_SEARCH)
    addDir("Khmer Live TV", khmertv, "khmer_livetv", ICON_KHMERTV)

    # Structured site definitions
    sites = [
        {
            "title": "KHMERAVE-MERLKON",
            "action": "index_khmeravenue",
            "categories": [
                ("KhmerAve", f"{KHMERAVENUE}album/", ICON_KHMERAVE),
                ("Melkon", f"{MERLKON}album/", ICON_MERLKON)
            ]
        },
        #{
        #    "title": "MERLKON",
        #    "logo": "https://www.khmerdrama.com/wp-content/themes/avenue/img/logo.png",
        #    "action": "index_merlkon",
        #    "categories": [
        #        ("Thai HD", f"{MERLKON}country/thailand/"),
        #        ("Thai Boran", f"{MERLKON}genre/thai-boran/"),
        #        ("Thai Horror", f"{MERLKON}genre/horror/"),
        #        ("Thai Mayura", f"{MERLKON}dubbed/mayura/"),
        #        ("Thai KM", f"{MERLKON}dubbed/km/"),
        #        ("Indian", f"{MERLKON}country/India/"),
        #        ("Philippines", f"{MERLKON}country/philippines/"),
        #        ("Cambodia", f"{MERLKON}country/cambodia/"),
        #        ("Kon", f"{MERLKON}albumcategory/kon/")
        #    ]
        #},        
        {
            "title": "VIDEO4KHMER",
            "logo": "https://www.video4khmer36.com/templates/pkakrovan/images/all/logo.png",
            "action": "index_video4u",
            "categories": [
                ("Cambodia", f"{VIDEO4KHMER}khmer-movie-category/khmer-drama-watch-online-free-catalogue-504-page-1.html"),
                ("Chinese Aired", f"{VIDEO4KHMER}khmer-movie-category/chinese-series-drama-to-be-continued-catalogue-2673-page-1.html"),
                ("Chinese Completed", f"{VIDEO4KHMER}khmer-movie-category/chinese-series-drama-watch-online-free-catalogue-506-page-1.html"),
                ("Thai Aired", f"{VIDEO4KHMER}khmer-movie-category/thai-lakorn-drama-to-be-continued-catalogue-2674-page-1.html"),
                ("Thai Completed", f"{VIDEO4KHMER}khmer-movie-category/thai-lakorn-drama-watch-online-free-catalogue-537-page-1.html"),
                ("Korean Aired", f"{VIDEO4KHMER}khmer-movie-category/korean-drama-to-be-continued-catalogue-508-page-1.html"),
                ("Korean Completed", f"{VIDEO4KHMER}khmer-movie-category/korean-drama-watch-online-free-catalogue-507-page-1.html")
            ]
        },
        {
            "title": "PHUMIK",
            "logo": "https://phumikhmer2.com/home/img/logo.png",
            "action": "index_phumik",
            "categories": [
                ("Thai", f"{PHUMIK}search/label/Thai?&max-results=24"),
                ("Chinese", f"{PHUMIK}search/label/Chinese?&max-results=24"),
                ("Korean", f"{PHUMIK}search/label/Korea?&max-results=24")
            ]
        },
        {
            "title": "CKCH7",
            "logo": "https://www.ckh7.com/uploads/custom-logo.png",
            "action": "index_ckch7",
            "categories": [
                ("Khmer", f"{CKCH7}category.php?cat=khmer"),
                ("Thai", f"{CKCH7}category.php?cat=thai"),
                ("Chinese", f"{CKCH7}category.php?cat=chinese")
            ]
        },
        {
            "title": "SUNDAY",
            "logo": "https://blogger.googleusercontent.com/img/a/AVvXsEhO8r8yjM0VEBOtd_jJmmEj4uitwA88jiFRLhStCQy3iP4YH4x0Z2_FpnV6HdMVtJx3i2mijjLIIA4cljJ04PwqPEg-md0fdMrV8pzC2s1IQpGuXsFMsG0kJgNBH9pke9tyiL0Hc_bhQG8_d25W9SET9Qq_clSlS-9kcBENe0Zk-XB5WpeaW_aRnlyxsA=s450",
            "action": "index_sunday",
            "categories": [
                ("SundayDrama", f"{SUNDAY}")
            ]
        }
    ]

    # ── Render all site headers and their categories ────────────
    for site in sites:
        header = f"============= [COLOR red] {site['title']} [/COLOR] ============="
        addDir(header, "", site['action'], site.get('logo', ''))  # fallback to empty string if no logo

        for category in site['categories']:
            if len(category) == 3:
                label, url, icon = category
            else:
                label, url = category
                icon = site.get('logo', '')  # fallback to site's logo

            addDir(label, url, site['action'], icon)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)



# Search function    
def SEARCH():
    sources = [
        ("KhmerAvenue",   lambda q: INDEX_GENERIC(f'{KHMERAVENUE}?s={quote_plus(q)}', 'index_khmeravenue', label_suffix=" [COLOR yellow]KHMERAVE[/COLOR]")),
        ("Merlkon",       lambda q: INDEX_GENERIC(f'{MERLKON}?s={quote_plus(q)}', 'index_merlkon', label_suffix=" [COLOR cyan]MERLKON[/COLOR]")),
        ("PhumiKhmer",    lambda q: SINDEX_PHUMIK(f'{PHUMIK}search?q={quote_plus(q)}')),
        ("Video4Khmer36", lambda q: SEARCH_VIDEO4U(q)),  # Pass plain, not encoded
        ("CKCH7",         lambda q: SINDEX_CKCH7(f'{CKCH7}search.php?keywords={quote_plus(q)}')),
        ("SUNDAY",        lambda q: SINDEX_SUNDAY(f'{SUNDAY}search?q={quote_plus(q)}')),        
    ]

    dialog = xbmcgui.Dialog()
    choice = dialog.select('Search From:', [label for label, _ in sources])
    if choice == -1:
        return
    keyboard = xbmc.Keyboard('', 'Enter Search Text')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return
    search_text = keyboard.getText()
    # Dispatch the appropriate search handler
    try:
        sources[choice][1](search_text)
    except Exception as e:
        xbmcgui.Dialog().notification("Search Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[{ADDON_ID}] Search dispatch failed: {e}", xbmc.LOGERROR)
  


# KhmerTV
def KHMER_LIVETV():
    try:
        xml_data = OpenURL(base64.b64decode(khmertv).decode("utf-8"))
        if isinstance(xml_data, bytes):
            xml_data = xml_data.decode("utf-8", errors="ignore")
        xml_data = "\n".join(line.strip() for line in xml_data.splitlines() if line.strip())
        xml_data = re.sub(r'&(?!amp;|lt;|gt;|apos;|quot;)', '&amp;', xml_data)
        root = ET.fromstring(xml_data)
        items = root.findall(".//channel/item") or root.findall(".//item")
        if not items:
            raise Exception("No <item> found")
        xbmc.log(f"[{ADDON_ID}] Loaded {len(items)} channels", xbmc.LOGINFO)
        for item in items:
            title = item.findtext("title", "No Title").strip()
            url   = item.findtext("link", "").strip()
            icon  = item.findtext("thumbnail", "").strip() or ICON_KHMERTV
            resolve = item.findtext("resolve", "false").strip().lower() == "true"
            if not url:
                xbmc.log(f"[{ADDON_ID}] Missing URL for: {title}", xbmc.LOGWARNING)
                continue
            li = xbmcgui.ListItem(label=title)
            li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
            li.getVideoInfoTag().setTitle(title)
            li.setProperty('IsPlayable', 'true' if resolve else 'false')
            action = "playloop" if resolve else "video_hosting"
            plugin_url = f"{sys.argv[0]}?action={action}&url={quote_plus(url)}"
            xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, plugin_url, li, not resolve)
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] KHMER_LIVETV load failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", "Failed to load Live TV feed.")



#### only vdo4k use "videolinks" #####
############## VIDEO4KHMER ****************** 
def INDEX_VIDEO4U(url):
    _render_video4u_listing(url, label_suffix=None, include_pagination=True)

def SEARCH_VIDEO4U(search_term):
    url = f"https://www.video4khmer36.com/search.php?keywords={quote_plus(search_term)}&page=1"
    _render_video4u_listing(url, label_suffix=" [COLOR red]VIDEO4KHMER[/COLOR]", include_pagination=False)

def _render_video4u_listing(url, label_suffix=None, include_pagination=True):
    soup, html = OpenSoup(url, return_html=True)
    
    for item in soup.find_all('div', class_='cover-item'):
        cover_thumb = item.find('div', class_='cover-thumb')
        if not cover_thumb:
            continue

        # Extract image from style
        style = cover_thumb.get('style', '')
        image = style.replace('background-image: url(', '').replace(')', '').strip()

        # Get <a> tag for title and link
        a_tag = cover_thumb.find('a', class_='hover-cover')
        if not a_tag:
            continue

        title = a_tag.get('title', 'No Title').strip()
        link  = a_tag.get('href', '').strip()

        # Extract episode text from the LAST video-stats span (if any)
        ep_text = ''
        stats = cover_thumb.find_all('div', class_='video-stats')
        for stat in stats:
            span = stat.find('span')
            if span and "Ep" in span.text:
                ep_text = span.get_text(strip=True)

        # Build final label
        label = f"{title} ({ep_text})" if ep_text else title
        if label_suffix:
            label += label_suffix

        addDir(label, link, "episode_video4u", image)

    # Pagination
    if include_pagination:
        for a in soup.select('ul.pagination a[href]'):
            page_url = a['href']
            page_num = re.sub(r'<i[^>]*></i>', '', a.decode_contents().strip())
            addDir(f"Page {page_num}", page_url, "index_video4u", "")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def EPISODE_VIDEO4U(url, name):
    html = OpenURL(url, as_text=True)
    decoded = html.decode("utf-8", errors="ignore") if isinstance(html, bytes) else html

    # --- One-time summary popup ---
    if ADDON.getSetting("summary_url") != url:
        m = re.search(r'<h2 class="h3">Summary:</h2>\s*<p class="justified-text">(.*?)</p>', decoded, re.DOTALL | re.IGNORECASE)
        if m:
            summary = re.sub(r'\s+', ' ', re.sub(r'<br\s*/?>', '\n', m.group(1))).strip()
            try:
                xbmcgui.Dialog().textviewer("Summary", summary)
                ADDON.setSetting("summary_url", url)
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] Summary popup failed: {e}", xbmc.LOGWARNING)

    # --- Parse episodes ---
    soup = BeautifulSoup(decoded, "html.parser")
    episodes = {}
    for tr in soup.select("#episode-list tbody tr"):
        td = tr.find("td")
        if not td: continue

        a = td.find("a")
        title = a.get_text(strip=True) if a else td.get_text(strip=True)
        link = a["href"] if a else url

        m = re.search(r'(\d+)', title)
        ep_num = int(m.group(1)) if m else 0
        if ep_num and ep_num not in episodes:
            episodes[ep_num] = (title, link)

    # --- Show episodes ---
    for ep_num in sorted(episodes):
        title, link = episodes[ep_num]
        addLink(title, link, "videolinks", "")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)



###### starting here use "episode_players" #######	
############## SUNDAY ****************** 
def INDEX_SUNDAY(url):
    render_sunday_listing(url, label_color=None, include_pagination=True)

def SINDEX_SUNDAY(url):  # For search results (no pagination, green label)
    render_sunday_listing(url, label_color="green", include_pagination=False)

def render_sunday_listing(url, label_color=None, include_pagination=True):
    try:
        headers = {
            'Referer': 'https://www.sundaydrama.com/',
            'User-Agent': USER_AGENT
        }

        html = OpenURL(url, headers=headers, as_text=True)
        if not html:
            xbmc.log(f"[KDUBBED] Empty response from URL: {url}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("Error", "Failed to retrieve SundayDrama content.")
            return

        soup = BeautifulSoup(html, 'html.parser')

        # ── Focus on main post container only ─────────────────
        main_container = soup.find('div', class_='blog-posts')
        if not main_container:
            xbmc.log("[KDUBBED] Could not find main post container.", xbmc.LOGWARNING)
            return

        # ── Extract drama cards from full entry blocks ────────
        for post in main_container.find_all('div', class_='entry-inner'):
            a_tag = post.find('a', class_='entry-image-wrap is-image')
            if not a_tag:
                continue

            v_link = a_tag.get('href', '').strip()
            v_title = a_tag.get('title', 'No Title').strip()

            # Get image
            v_image = ''
            span_tag = a_tag.find('span')
            if span_tag and span_tag.has_attr('data-src'):
                v_image = span_tag['data-src'].strip()
                # Resize image for faster loading
                if "bp.blogspot.com" in v_image:
                    v_image = re.sub(r'/s\d+/', '/s320/', v_image)   
            else:
                img_tag = a_tag.find('img')
                if img_tag and img_tag.has_attr('src'):
                    v_image = img_tag['src'].strip()

            # ── Build final label (no status badge) ─────────────
            label = v_title
            if label_color:
                label += f" [COLOR {label_color}]SUNDAY[/COLOR]"

            if v_link:
                addDir(label, v_link, "episode_players", v_image)

        # ── Pagination ─────────────────────────────────────────
        if include_pagination:
            next_page = soup.find('a', class_='blog-pager-older-link')
            if next_page and next_page.has_attr('href'):
                next_url = html_unescape(next_page['href'])
                if "?m=1" not in next_url:
                    next_url += "&m=1" if "?" in next_url else "?m=1"
                xbmc.log(f"[KDUBBED] Next page URL: {next_url}", xbmc.LOGDEBUG)
                addDir('[B]Next Page >>>[/B]', next_url, "index_sunday", '')

        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

    except Exception as e:
        import traceback
        xbmc.log(f"[KDUBBED] render_sunday_listing failed: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", "Could not load SundayDrama page.")
  
    
############## ckch7 ****************** 
def INDEX_CKCH7(url):
    _render_ckch7_listing(url, label_color=None)

def SINDEX_CKCH7(url): # For search results (no pagination, green label)
    _render_ckch7_listing(url, label_color="green")

def _render_ckch7_listing(url, label_color=None):
    url = unquote_plus(url)
    soup, html = OpenSoup(url, return_html=True)

    # ── 1. Video cards ─────────────────────────────────────────────
    for card in soup.select("div.col-xs-6.col-sm-6.col-md-3"):
        a = card.find("a", href=True)
        img = card.find("img")
        if not (a and img):
            continue

        v_link = urljoin(CKCH7, a["href"])
        v_title = img.get("alt", "No Title").strip()
        v_image = img.get("data-echo") or img.get("src", "")
        label = f"{v_title} [COLOR {label_color}]CKCH7[/COLOR]" if label_color else v_title
        addDir(label, v_link, "episode_players", v_image)

    # ── 2. Pagination (skip for search) ─────────────────────────────
    if not label_color:  # only add pagination in non-search mode
        pag_ul = soup.find("ul", class_="pagination")
        if pag_ul:
            for li in pag_ul.find_all("li"):
                if li.get("class") and {"active", "disabled"} & set(li["class"]):
                    continue
                a = li.find("a", href=True)
                if not a:
                    continue
                label = a.get_text(strip=True).replace("«", "<").replace("»", ">")
                page_url = urljoin(CKCH7, a["href"])
                encoded_url = quote_plus(page_url)
                addDir(f"Page {label}", encoded_url, "index_ckch7", "")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


############## phumikhmer2 ****************** 
def INDEX_PHUMIK(url):
    _render_phumik_listing(url, label_suffix=None, include_pagination=True)

def SINDEX_PHUMIK(url):  # for search
    _render_phumik_listing(url, label_suffix=" [COLOR green]PHUMIK[/COLOR]", include_pagination=False)

def _render_phumik_listing(url, label_suffix=None, include_pagination=True):
    soup, html = OpenSoup(url, return_html=True)
    
    # ------- 1 · Video cards -------------------------------------------------
    for wrap in soup.find_all('div', class_='post-filter-inside-wrap'):
        a_tag  = wrap.find('a', class_='post-filter-link')
        h2_tag = wrap.find('h2', class_=re.compile(r'entry-title'))
        img_tag = wrap.find('img', class_='snip-thumbnail')
        if not (a_tag and h2_tag and img_tag):
            continue

        v_link  = a_tag['href']
        v_title = h2_tag.get_text(strip=True)
        v_image = img_tag.get('data-src') or img_tag.get('src', '')
        v_image = re.sub(r'/w\d+-h\d+[^/]+/', '/s1600/', v_image)

        label = f"{v_title}{label_suffix}" if label_suffix else v_title
        addDir(label, v_link, "episode_players", v_image)

    # ------- 2 · Pagination --------------------------------------------------
    if include_pagination:
        for page_url in re.findall(r"<a[^>]*class='blog-pager-older-link'[^>]*href='([^']+)'", html):
            addDir('NEXT PAGE', page_url, "index_phumik", "")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
      
	
############## KhmerAve Melkon SITE ****************** 		  
def INDEX_GENERIC(url, action, site_name='', label_suffix=None):
    soup, html = OpenSoup(url, return_html=True)

    # KhmerAvenue (Chinese) uses 'thumbnail-container' vs Melkon and KhmerAvenue (Korean) use 'card-content'
    div_index = soup.find_all('div', class_="col-6 col-sm-4 thumbnail-container")
    layout_type = 'thumbnail' if div_index else 'card'
    if layout_type == 'card':
        div_index = soup.find_all('div', class_='card-content')

    for item in div_index:
        try:
            if layout_type == 'thumbnail':
                # ------- KhmerAvenue (Chinese layout) -------
                a_tag = item.find('a')
                h3_tag = item.find('h3')
                h4_tag = item.find('h4')  # optional episode number
                image_div = item.find('div', style=True)

                v_link = a_tag['href']
                v_title = h3_tag.get_text(strip=True).replace("&#8217;", "")
                v_info = h4_tag.get_text(strip=True).replace("Episode", "").strip() if h4_tag else ""
                v_name = f"{v_title} {v_info}".strip()

                # Extract image from inline CSS
                v_image = ""
                if image_div:
                    style = image_div.get('style', '')
                    match = re.findall(r'\((.+?)\)', style)
                    if match:
                        v_image = match[0]

            else:
                # ------- Melkon or KhmerAvenue (Korean card layout) -------
                a_tag = item.find('a', href=True)
                title_tag = item.find('h3')
                episode_tag = item.find('span', class_='card-content-episode-number')
                image_div = item.find('div', class_='card-content-image')

                v_link = a_tag['href'] if a_tag else ""
                v_title = title_tag.get_text(strip=True) if title_tag else ""
                v_info = episode_tag.get_text(strip=True).replace("Ep", "").strip() if episode_tag else ""
                v_name = f"{v_title} {v_info}".strip()

                # Extract image from background style
                v_image = ""
                if image_div and 'style' in image_div.attrs:
                    style = image_div['style']
                    match = re.search(r'url\((.*?)\)', style)
                    if match:
                        v_image = match.group(1)

            if v_link and v_title:
                label = f"{v_name}{label_suffix}" if label_suffix else v_name
                addDir(label, v_link, "episode_players", v_image)

        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] INDEX_GENERIC ({site_name}) item error: {str(e)}", xbmc.LOGWARNING)

    # -------- Pagination --------
    html = str(soup)
    match = re.search(r"<div[^>]*class=['\"]wp-pagenavi['\"][^>]*>(.*?)</div>", html, re.DOTALL)
    if match:
        pages = re.findall(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', match.group(1))
        for page_url, page_num in pages:
            addDir(f"Page {page_num}", page_url, action, "") 


############## use for sundaydrama episode ****************** 
BLOG_ID_CACHE = {}

BLOG_ID_SEEN = set()

BLOG_ID_BASELINE = {
    "2": "7871281676618369095",
    "4": "596013908374331296",
    "":  "3556626157575058125",
} 

"""
Guide to Finding the Blogger Blog ID and Server Index:

1. Open the webpage and view the page source (Ctrl+U or right-click > View page source).
2. Search for the string "fanta".
   Example found:
       <div id="fanta" data-post-id="4534454511319106355" data-server-index="4"></div>
3. Copy the `data-post-id` value (e.g., 4534454511319106355) and search for it using Inspect (DevTools).
4. You should find a script tag like this:
       <script src="https://www.blogger.com/feeds/596013908374331296/posts/default/4534454511319106355?alt=json-in-script&callback=fetchBloggerPostContent"></script>
5. Extract the following values:
   - Blog ID:        596013908374331296
   - Post ID:        4534454511319106355
   - Server Index:   "4" (as seen in data-server-index)
6. Use Server Index and Blod ID as for BLOG_ID_BASELINE

Special Case:
If the source only shows:
    <div id="fanta" data-post-id="8526567538163274964"></div>
Then no data-server-index is present, so treat it as an empty string ("").
Example script tag:
    <script src="https://www.blogger.com/feeds/3556626157575058125/posts/default/8526567538163274964?alt=json-in-script&callback=fetchBloggerPostContent"></script>
"""

ADDON_DATA_PATH = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.KDubbed")
if not os.path.exists(ADDON_DATA_PATH):
    try:
        os.makedirs(ADDON_DATA_PATH)
    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to create addon data path: {e}", xbmc.LOGWARNING)

BLOG_ID_CACHE_PATH = os.path.join(ADDON_DATA_PATH, "blog_id_cache.json")

def load_blog_id_cache_from_disk():
    global BLOG_ID_CACHE, BLOG_ID_SEEN
    if os.path.exists(BLOG_ID_CACHE_PATH):
        try:
            with open(BLOG_ID_CACHE_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            BLOG_ID_CACHE = data.get("map", {})
            BLOG_ID_SEEN = set(data.get("seen", []))
            xbmc.log(f"[KDUBBED] Loaded BLOG_ID_CACHE: {BLOG_ID_CACHE}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[KDUBBED] Failed to load BLOG_ID_CACHE: {e}", xbmc.LOGWARNING)

def save_blog_id_cache_to_disk():
    try:
        data = {"map": BLOG_ID_CACHE, "seen": list(BLOG_ID_SEEN)}
        with open(BLOG_ID_CACHE_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f)
        xbmc.log("[KDUBBED] Saved BLOG_ID_CACHE.", xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to save BLOG_ID_CACHE: {e}", xbmc.LOGWARNING)

load_blog_id_cache_from_disk()

def _learn_mapping(server_index, blog_id, source="unknown"):
    prev = BLOG_ID_CACHE.get(server_index)
    if prev != blog_id:
        BLOG_ID_CACHE[server_index] = blog_id
        xbmc.log(
            f"[KDUBBED] Learned blog_id mapping: server_index={server_index} -> {blog_id} (source={source}, prev={prev})",
            xbmc.LOGINFO
        )
        save_blog_id_cache_to_disk()
    if blog_id not in BLOG_ID_SEEN:
        BLOG_ID_SEEN.add(blog_id)
        save_blog_id_cache_to_disk()

def extract_blog_id_mapping_from_scripts(html):
    matches = re.findall(
        r'src=["\']https://www\\.blogger\\.com/feeds/(\d+)/posts/default/(\d+)\?alt=json-in-script',
        html
    )
    mapping = {}
    for blog_id, post_id in matches:
        BLOG_ID_SEEN.add(blog_id)
        div_match = re.search(
            fr'<div[^>]+data-post-id=["\']{post_id}["\'][^>]*data-server-index=["\']?(\d*)["\']?',
            html
        )
        if div_match:
            server_index = div_match.group(1) or ""
            mapping[server_index] = blog_id
            _learn_mapping(server_index, blog_id, source="script-tag")
    if matches:
        save_blog_id_cache_to_disk()
    return mapping

def _get_blog_id_for_server_index(server_index):
    if server_index in BLOG_ID_CACHE:
        return BLOG_ID_CACHE[server_index]
    if server_index in BLOG_ID_BASELINE:
        blog_id = BLOG_ID_BASELINE[server_index]
        _learn_mapping(server_index, blog_id, source="baseline")
        return blog_id
    return None

def extract_all_blogger_json_urls_from_page(html):
    extract_blog_id_mapping_from_scripts(html)
    matches = re.findall(
        r'<div[^>]+id=["\']fanta["\'][^>]*data-post-id=["\'](\d+)["\'](?:[^>]*data-server-index=["\']?(\d*)["\']?)?',
        html
    )
    urls = []
    for post_id, server_index in matches:
        server_index = server_index or ""
        blog_id = _get_blog_id_for_server_index(server_index)
        if blog_id:
            feed_url = f"https://www.blogger.com/feeds/{blog_id}/posts/default/{post_id}?alt=json"
            urls.append(feed_url)
        else:
            xbmc.log(
                f"[KDUBBED] Unknown server index: {server_index} for post ID {post_id} (no mapping; cache={BLOG_ID_CACHE})",
                xbmc.LOGWARNING
            )
    return urls

def parse_blogger_video_links(blogger_post_url):
    if "alt=json-in-script" in blogger_post_url:
        blogger_post_url = blogger_post_url.split("?")[0] + "?alt=json-in-script"
    elif "?alt=" not in blogger_post_url:
        blogger_post_url = blogger_post_url.split("?")[0] + "?alt=json"

    try:
        response = OpenURL(blogger_post_url, as_text=True)

        if response.strip().startswith("fetchBloggerPostContent("):
            match = re.search(r'fetchBloggerPostContent\((\{.*\})\);?$', response.strip(), re.DOTALL)
            if not match:
                raise ValueError("Invalid JSONP response format")
            json_text = match.group(1)
        else:
            json_text = response

        data = json.loads(json_text)
        raw_html = data.get("entry", {}).get("content", {}).get("$t", "")
        decoded_html = html_unescape(raw_html)

        links = []

        # --- Extract and validate .aaa/.gaa.mp4 links (only validate the first) ---
        mp4_links = re.findall(r"https:\/\/[^\s\"'>]+?\.(?:aaa|gaa)\.mp4", decoded_html)
        validated = False
        for index, video_url in enumerate(mp4_links, start=1):
            if not validated:
                if is_url_valid(video_url, referer='https://www.sundaydrama.com/'):
                    validated = True
                    links.append({'file': video_url, 'title': f"Episode {index}"})
                else:
                    xbmc.log(f"[{ADDON_ID}] Skipped invalid first link: {video_url}", xbmc.LOGWARNING)
                    break
            else:
                links.append({'file': video_url, 'title': f"Episode {index}"})

        # --- Fallback: bigo.sg .mp4 links ---
        if not links:
            bigo_links = re.findall(r"\/\/bigf\.bigo\.sg\/[^\s\"'>]+\.mp4", decoded_html)
            for index, path in enumerate(bigo_links, start=1):
                video_url = "https:" + path.replace('\\/', '/')
                if is_url_valid(video_url):
                    links.append({'file': video_url, 'title': f"Episode {index}"})

        # --- Fallback: OK.ru embeds ---
        if not links:
            if "{embed=ok}" in decoded_html or "ok.ru/videoembed/" in decoded_html:
                okru_ids = re.findall(r"\b\d{10,}\b", decoded_html)
                for index, video_id in enumerate(sorted(okru_ids), start=1):
                    video_url = f"https://ok.ru/videoembed/{video_id}"
                    links.append({'file': video_url, 'title': f"Episode {index}"})
                xbmc.log(f"[{ADDON_ID}] Used OK.ru fallback for: {blogger_post_url}", xbmc.LOGINFO)
            else:
                xbmc.log(f"[{ADDON_ID}] Skipped OK.ru fallback due to missing marker: {blogger_post_url}", xbmc.LOGINFO)

        if not links:
            xbmc.log(f"[{ADDON_ID}] No playable video links found in Blogger feed: {blogger_post_url}", xbmc.LOGWARNING)

        return links

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] Error parsing Blogger video links from URL {blogger_post_url}: {e}", xbmc.LOGERROR)
        return []

def is_url_valid(url, referer=None):
    try:
        headers = {
            'User-Agent': USER_AGENT
        }
        if referer:
            headers['Referer'] = referer

        response = requests.head(url, headers=headers, allow_redirects=True, timeout=5)
        return response.status_code == 200 and int(response.headers.get('Content-Length', 0)) > 1024 * 50
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] HEAD check failed for {url}: {e}", xbmc.LOGWARNING)
        return False       
############## end ****************** 


############## episode_players ****************** 
def EPISODE_PLAYERS(url, name):
    links_found = False

    if "sundaydrama.com" in url:
        html = OpenURL(url, as_text=True)
        blogger_urls = extract_all_blogger_json_urls_from_page(html)

        all_links = []
        episode_counter = 1
        for blogger_url in blogger_urls:
            xbmc.log(f"[{ADDON_ID}] Extracted Blogger URL: {blogger_url}", xbmc.LOGINFO)
            links = parse_blogger_video_links(blogger_url)
            if links:
                for link in links:
                    link['title'] = f"Episode {episode_counter}"
                    episode_counter += 1
                all_links.extend(links)

        if all_links:
            DIRECT_EXTENSIONS = (".mp4", ".m3u8", ".aaa.mp4", ".gaa.mp4")
            for item in all_links:
                vurl = item['file']
                vtitle = item['title']

                if any(host in vurl for host in ["ok.ru", "youtube.com", "youtu.be", "vimeo.com"]):
                    addLink(vtitle, vurl, "video_hosting", '')
                elif any(vurl.split('?')[0].endswith(ext) for ext in DIRECT_EXTENSIONS):
                    addLink(vtitle, vurl, "play_direct", '')
                else:
                    addLink(vtitle, vurl, "video_hosting", '')  # fallback

            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return
        else:
            xbmcgui.Dialog().ok("No Episodes Found", "No playable episodes found in Blogger posts.")
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return

    # Blogger JSON feed direct
    if "blogger.com/feeds/" in url:
        blogger_links = parse_blogger_video_links(url)
        if blogger_links:
            for item in blogger_links:
                addLink(item['title'], item['file'], "play_direct", '')
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return
        else:
            xbmcgui.Dialog().ok("No Episodes Found", "No playable episodes found in Blogger feed.")
            xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
            return




    # ── Load standard HTML and parse ─────────────────────────────
    html = OpenURL(url)
    decoded = html.decode("utf-8") if isinstance(html, bytes) else html

    def show_about_section():
        if ADDON.getSetting("about_url") == url:
            return
        m = re.search(
            r'<div[^>]+id=["\']about["\'][^>]*>.*?<p[^>]*class=["\']album-content-description["\'][^>]*>(.*?)</p>',
            decoded, re.DOTALL | re.IGNORECASE)
        if m:
            about = re.sub(r'\s+', ' ', re.sub(r'<br\s*/?>', '\n', m.group(1))).strip()
            try:
                xbmcgui.Dialog().textviewer("About", about)
                ADDON.setSetting("about_url", url)
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] Failed to show About popup: {e}", xbmc.LOGWARNING)

    def get_submitter():
        m = re.search(r'Submitter:\s*<b[^>]*>([^<]+)</b>', decoded, re.IGNORECASE)
        return m.group(1).strip() if m else ""

    def parse_episode_table():
        table = re.search(r'<table id="latest-videos"[^>]*>(.*?)</table>', decoded, re.DOTALL)
        if table:
            return re.findall(r'<td>\s*<a href="([^"]+)">\s*(?:<i[^>]*></i>)?\s*([^<]+)\s*</a>', table.group(1))
        return re.findall(
            r'<div class="col-xs-6 col-sm-6 col-md-3">.*?<a href="([^"]+)"[^>]*>\s*(?:<i[^>]*></i>)?\s*([^<]+)\s*</a>',
            decoded, re.DOTALL
        )

    def try_player_list_json():
        m = re.search(r"options\.player_list\s*=\s*(\[[^\]]+\])\s*;", decoded, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(1))
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] json.loads failed: {e}", xbmc.LOGWARNING)
        return None

    def try_player_list_eval():
        m = re.search(r"options\.player_list\s*=\s*(\[[^\]]+\])\s*;", decoded.replace("null", "None"), re.DOTALL)
        if m:
            try:
                return ast.literal_eval(m.group(1))
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] ast.literal_eval failed: {e}", xbmc.LOGWARNING)
        return None

    def try_videos_list_const(): #ckch7/sunday
        m = re.search(r"const\s+videos\s*=\s*(\[[\s\S]+?\])\s*;", decoded)
        if m:
            raw = m.group(1)
            raw = re.sub(r",\s*([\]}])", r"\1", raw)
            raw = re.sub(r'([{\s,])(\w+)\s*:', r'\1"\2":', raw)
            raw = raw.replace("'", '"')
            try:
                return json.loads(raw)
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] json.loads failed on cleaned const videos list: {e}", xbmc.LOGWARNING)
        return None

    def try_fallback_player_list():
        return [{'file': f, 'title': t} for f, t in re.findall(
            r"[{[]\s*['\"]file['\"]\s*:\s*['\"](.+?)['\"],\s*['\"]title['\"]\s*:\s*['\"](.+?)['\"]", decoded)]

    # ── Begin parsing ────────────────────────────────────────────
    show_about_section()
    submitter = get_submitter()

    for v_link, v_title in reversed(parse_episode_table()):
        v_link = urljoin(url, v_link)
        v_title = v_title.replace("Episode", "Part").strip()
        if submitter:
            v_title += f" [COLOR grey](by {submitter})[/COLOR]"
        addLink(v_title, v_link, "videolinks", '')
        links_found = True

    if not links_found:
        player_list = (
            try_player_list_json() or
            try_player_list_eval() or
            try_videos_list_const() or
            try_fallback_player_list()
        )

        if player_list:
            for item in reversed(player_list):
                try:
                    v_link = item.get('file', '').strip()
                    v_title = html_unescape(item.get('title', '').strip())
                    v_title = re.sub(r'^([\w]+\.)[^–]*?&#8211;\s*', r'\1 ', v_title)
                    v_title = re.sub(r'&#60\d{2,3};', '', v_title)

                    if not (v_link and v_title):
                        continue

                    if submitter:
                        v_title += f" [COLOR grey](by {submitter})[/COLOR]"

                    if (
                        "1a-1791.com" in v_link or
                        v_link.endswith(".aaa.mp4") or
                        any(domain in v_link for domain in ["ckh7.com", "sundaydrama.com"])
                    ):
                        addLink(v_title, v_link, "play_direct", '')
                    else:
                        addLink(v_title, v_link, "video_hosting", '')

                    links_found = True
                except Exception as e:
                    xbmc.log(f"[{ADDON_ID}] Failed to parse video item: {e}", xbmc.LOGWARNING)

    if not links_found:
        xbmcgui.Dialog().ok("No Episodes Found", "Sorry, no playable episodes were detected.")
        xbmc.log(f"[{ADDON_ID}] No episode links found at: {url}", xbmc.LOGWARNING)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def VIDEOLINKS(url):
    content = str(OpenSoup(url))  # Ensure string format
    blacklist = ['googletagmanager.com', 'facebook.com', 'twitter.com', 'doubleclick.net']

    def is_blacklisted(link):
        return any(bad in link for bad in blacklist)

    def try_base64_iframe():
        matches = re.findall(r'Base64.decode\("(.+?)"\)', content)
        if matches:
            try:
                decoded = base64.b64decode(matches[0]).decode('utf-8', errors='ignore')
                iframe = re.search(r'<iframe[^>]+src="(.+?)"', decoded)
                if iframe:
                    VIDEO_HOSTING(iframe.group(1))
                    return True
            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] Base64 decode failed: {e}", xbmc.LOGWARNING)
        return False

    def try_patterns():
        patterns = [
            r'[\'"]?file[\'"]?\s*:\s*[\'"]([^\'"]+)[\'"]',
            r'<iframe src="(.+?)" class="video allowfullscreen="true">',
            r'<iframe frameborder="0" [^>]*src="(.+?)">',
            r'<IFRAME SRC="(.+?)" [^>]*',
            r'<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>',
            r"var flashvars = {file: '(.+?)',",
            r'swfobject\.embedSWF\("(.+?)",',
            r'src="(.+?)" allow="autoplay"',
            r'<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>',
            r'<source [^>]*src="([^"]+?)"',
            r'playlist: "(.+?)"',
            r'<!\[CDATA\[(.*?)\]\]></tvurl>'
        ]
        for pattern in patterns:
            matches = re.findall(pattern, content)
            for url in matches:
                if not is_blacklisted(url):
                    VIDEO_HOSTING(url)
                    return True
        return False

    if try_base64_iframe() or try_patterns():
        return
    xbmc.log(f"[{ADDON_ID}] No video URL found in VIDEOLINKS()", xbmc.LOGWARNING)
    
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def enable_inputstream_adaptive():
    try:
        addon_id = "inputstream.adaptive"

        if not xbmc.getCondVisibility(f"System.HasAddon({addon_id})"):
            xbmc.log(f"[KDUBBED] Installing {addon_id}...", xbmc.LOGINFO)
            xbmc.executebuiltin(f"InstallAddon({addon_id})")

        if not xbmc.getCondVisibility(f"System.AddonIsEnabled({addon_id})"):
            xbmc.log(f"[KDUBBED] Enabling {addon_id}...", xbmc.LOGINFO)
            xbmc.executebuiltin(f"EnableAddon({addon_id})")

    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to enable {addon_id}: {e}", xbmc.LOGWARNING)


def Playloop(video_url):
    xbmc.log(f"[KDUBBED] PLAY VIDEO: {video_url}", xbmc.LOGINFO)

    # Safer header formatting (quote_plus ensures URL-safe encoding)
    headers_dict = {
        'verifypeer': 'false',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/90 Safari/537.36',
        'Referer': 'https://live-ali7.tv360.metfone.com.kh/',
    }
    headers = '&'.join(f'{k}={quote_plus(v)}' for k, v in headers_dict.items())
    full_url = f"{video_url}|{headers}"

    item = xbmcgui.ListItem(path=full_url)

    # Configure for adaptive HLS streaming
    item.setMimeType('application/vnd.apple.mpegurl')
    item.setContentLookup(False)
    item.setProperty('inputstream', 'inputstream.adaptive')
    item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')
    item.setProperty('inputstream.adaptive.heuristicstreamselection', 'true')  # Optional but helpful

    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)


def VIDEO_HOSTING(vlink):
    resolved = None
    RESOLVABLE_HOSTS = ('ok.ru', 'youtube.com', 'youtu.be', 'youtube-nocookie.com', 'vimeo.com', 'dailymotion.com')

    # Try resolveurl for known hosts
    if any(host in vlink for host in RESOLVABLE_HOSTS):
        try:
            resolved = resolveurl.resolve(vlink)
            if resolved:
                xbmc.log(f"[KDUBBED] Resolved URL via resolveurl: {resolved}", xbmc.LOGINFO)
                Play_VIDEO(resolved)
                return
            else:
                xbmc.log(f"[KDUBBED] resolveurl returned None for: {vlink}", xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f"[KDUBBED] resolveurl error for {vlink}: {e}", xbmc.LOGWARNING)

    # Fallback to direct play
    xbmc.log(f"[KDUBBED] Fallback to Play_VIDEO(): {vlink}", xbmc.LOGINFO)
    xbmc.executebuiltin("Notification(Please Wait!, KhmerDubbed is loading...)")
    Play_VIDEO(vlink)

    

def Play_VIDEO(VideoURL):
    if not VideoURL:
        xbmcgui.Dialog().ok("Playback Error", "No video URL provided.")
        xbmc.log("[KDUBBED] Empty video URL passed to Play_VIDEO()", xbmc.LOGWARNING)
        return

    xbmc.log(f"[KDUBBED] Playing video: {VideoURL}", xbmc.LOGINFO)

    # Plugin URLs (like plugin://plugin.video.youtube/...) must not include headers
    if VideoURL.startswith("plugin://"):
        item = xbmcgui.ListItem(path=VideoURL)
        item.setInfo(type="Video", infoLabels={"title": "Playing..."})
        xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item)
        return

    # Parse embedded headers if any (ckch7/sunday)
    if "|" in VideoURL:
        VideoURL, header_str = VideoURL.split("|", 1)
        header_parts = header_str.split("|")
        headers = dict(part.split("=", 1) for part in header_parts if "=" in part)
    else:
        headers = {}

    # === Automatically Set Proper Referer ===
    referer = headers.get("Referer", "").lower()

    if not referer:
        if "1a-1791.com" in VideoURL:
            # Heuristic fallback: prefer sundaydrama.com if unsure
            referer = "https://sundaydrama.com/" if "sundaydrama.com" in VideoURL else "https://www.ckh7.com/"
        elif "sundaydrama.com" in VideoURL:
            referer = "https://sundaydrama.com/"
        elif "ckh7.com" in VideoURL:
            referer = "https://www.ckh7.com/"
        else:
            referer = "https://www.ckh7.com/"  # Default fallback

    headers.setdefault("Referer", referer)
    headers.setdefault("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")

    # Reconstruct final URL with headers
    header_string = "&".join([f"{k}={v}" for k, v in headers.items()])
    final_url = f"{VideoURL}|{header_string}"

    item = xbmcgui.ListItem(path=final_url)
    item.setInfo(type="Video", infoLabels={"title": "Playing..."})
    item.setContentLookup(False)

    # Enable inputstream.adaptive if applicable
    if ".m3u8" in VideoURL or "manifest" in VideoURL:
        item.setMimeType("application/vnd.apple.mpegurl")
        item.setProperty("inputstream", "inputstream.adaptive")
        item.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")
        item.setProperty("inputstream.adaptive.heuristicstreamselection", "true")
    else:
        item.setMimeType("video/mp4")

    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, item) 
    


# ----- Utility Functions -----
def addLink(name, url, action, iconimage=""):
    u = f"{sys.argv[0]}?url={quote_plus(url)}&action={quote_plus(action)}&name={quote_plus(name)}"
    li = xbmcgui.ListItem(label=name)
    li.setArt({'icon': iconimage, 'poster': iconimage, 'thumb': iconimage})
    li.getVideoInfoTag().setTitle(name)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=False)


def addDir(name, url, action, iconimage=""):
    u = f"{sys.argv[0]}?url={quote_plus(str(url))}&action={quote_plus(str(action))}&name={quote_plus(str(name))}"
    li = xbmcgui.ListItem(label=name)
    if iconimage:
        li.setArt({'thumb': iconimage, 'icon': iconimage, 'poster': iconimage})
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=True)


def get_params():
    param = {}
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else sys.argv[2]
    for pair in paramstring.split('&'):
        if '=' in pair:
            key, value = pair.split('=', 1)
            param[key] = unquote_plus(value)
    return param


# ----- Parameter Parsing -----
params = get_params()
url    = params.get("url", "")
name   = params.get("name", "")
action = params.get("action", "home")


# ----- Show Popup -----
if ADDON.getSettingBool("show_support_popup") and action == "home":
    xbmcgui.Dialog().ok(
        "KhmerUnitedKhmer",
        "[COLOR=yellow]Justice For Cambodia[/COLOR]\n"
        "[COLOR=red]Thailand Attacks First,[/COLOR] [COLOR=green]Cambodia Defends[/COLOR]\n"
        "[COLOR=white]Use hashtag [COLOR=cyan]#JusticeForCambodia[/COLOR] on your social media and let your voice be heard.[/COLOR]"
    )


# ----- Routing -----
ROUTES = {
    "home":              lambda: HOME(),
    "playloop":          lambda: Playloop(url),
    "videolinks":        lambda: VIDEOLINKS(url),
    "video_hosting":     lambda: VIDEO_HOSTING(url),
    "search":            lambda: SEARCH(),
    "index_video4u":     lambda: INDEX_VIDEO4U(url),
    "episode_video4u":   lambda: EPISODE_VIDEO4U(url, name),    
    "index_khmeravenue": lambda: INDEX_GENERIC(url, "index_khmeravenue", 'khmeravenue'),
    "index_merlkon":     lambda: INDEX_GENERIC(url, "index_merlkon", 'merlkon'),
    "index_korean":      lambda: INDEX_GENERIC(url, "index_korean", 'korean'),
    "index_ckch7":       lambda: INDEX_CKCH7(url),
    "index_sunday":      lambda: INDEX_SUNDAY(url),
    "play_direct":       lambda: Play_VIDEO(url), #ckch7/sunday
    "index_phumik":      lambda: INDEX_PHUMIK(url),
    "episode_players":   lambda: EPISODE_PLAYERS(url, name),    
    "khmer_livetv":      lambda: KHMER_LIVETV(),
}

# ----- Execute Action -----
ROUTES.get(action, lambda: HOME())()


# ----- End of Directory -----
xbmcplugin.endOfDirectory(PLUGIN_HANDLE)