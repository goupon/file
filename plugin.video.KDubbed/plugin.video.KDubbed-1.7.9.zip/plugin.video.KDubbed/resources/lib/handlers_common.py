# ────────────────────────────────────────────────
# Common constants and utilities shared across handlers
# ────────────────────────────────────────────────

USER_AGENT = (
    "Mozilla/5.0 (Linux; Android 10; K) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/137.0.0.0 Mobile Safari/537.36"
)
