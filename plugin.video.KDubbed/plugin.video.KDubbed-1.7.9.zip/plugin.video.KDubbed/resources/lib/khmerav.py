# ────────────────────────────────────────────────
#  KHMERAVENUE & MERLKON (KHMERDRAMA) SITE HANDLER
# ────────────────────────────────────────────────
import re, sys, json, xbmc, xbmcplugin, xbmcgui
from urllib.parse import urljoin, quote_plus, unquote_plus
from bs4 import BeautifulSoup

# ── Local Handlers ──────────────────────────────
from resources.lib.handlers_khmer import (
    OpenSoup as OpenSoup_KH,
    OpenURL as OpenURL_KH,
)
from resources.lib.handlers_common import USER_AGENT
from resources.lib.handlers_blogid import ADDON_ID
try:
    ADDON_ID
except NameError:
    ADDON_ID = "plugin.video.KDubbed"

# ── Local Constants ─────────────────────────────
KHMERAVENUE = "https://www.khmeravenue.com/"
MERLKON     = "https://www.khmerdrama.com/"
PLUGIN_HANDLE = int(sys.argv[1])


############## KhmerAve / Merlkon SITE ****************** 		  
def INDEX_GENERIC(url, action, site_name='', label_suffix=None):
    try:
        headers = {'User-Agent': USER_AGENT}
        if 'khmeravenue.com' in url or site_name == 'khmeravenue':
            headers['Referer'] = KHMERAVENUE
        elif 'khmerdrama.com' in url or site_name == 'merlkon':
            headers['Referer'] = MERLKON

        soup, html = OpenSoup_KH(url, return_html=True, headers=headers)

        # KhmerAvenue (Chinese) → "thumbnail-container"
        # Merlkon / KhmerAvenue (Korean) → "card-content"
        items = soup.select('div.col-6.col-sm-4.thumbnail-container, div.card-content')

        # Helper: extract image URL from inline CSS style
        def style_url(style):
            if not style:
                return ""
            m = re.search(r'url\((.*?)\)', style)
            return m.group(1) if m else ""

        for item in items:
            try:
                is_thumb = 'thumbnail-container' in (item.get('class') or [])

                if is_thumb:
                    # -------- KhmerAvenue (Chinese layout) --------
                    a_tag   = item.find('a')
                    h3_tag  = item.find('h3')
                    h4_tag  = item.find('h4')
                    v_link  = (a_tag or {}).get('href', '')
                    v_title = (h3_tag.get_text(strip=True) if h3_tag else '').replace("&#8217;", "")
                    v_info  = (h4_tag.get_text(strip=True) if h4_tag else '').replace("Episode", "").strip()
                    v_image = style_url((item.find('div', style=True) or {}).get('style'))

                else:
                    # -------- Merlkon / KhmerAvenue (Korean layout) --------
                    a_tag   = item.find('a', href=True)
                    v_link  = a_tag['href'] if a_tag else ''
                    v_title = (item.find('h3').get_text(strip=True) if item.find('h3') else '')
                    ep_tag  = item.find('span', class_='card-content-episode-number')
                    v_info  = (ep_tag.get_text(strip=True) if ep_tag else '').replace("Ep", "").strip()
                    img_div = item.find('div', class_='card-content-image')
                    v_image = style_url(img_div.get('style') if img_div else '')

                if v_link and v_title:
                    name  = f"{v_title} {v_info}".strip()
                    label = f"{name}{label_suffix}" if label_suffix else name
                    addDir(label, v_link, "episode_players", v_image)

            except Exception as e:
                xbmc.log(f"[{ADDON_ID}] INDEX_GENERIC ({site_name}) item error: {str(e)}", xbmc.LOGWARNING)

        # -------- Pagination --------
        try:
            nav = soup.select_one('nav.navigation.pagination .nav-links')
            if nav:
                for a in nav.select('a.page-numbers[href]'):
                    text, href = a.get_text(strip=True), urljoin(url, a['href'])
                    classes = a.get('class') or []
                    if 'next' in classes:
                        addDir('Next »', href, action, '')
                    elif 'prev' in classes:
                        addDir('« Previous', href, action, '')
                    elif text.isdigit():
                        addDir(f'Page {text}', href, action, '')
        except Exception as e:
            xbmc.log(f"[{ADDON_ID}] INDEX_GENERIC pagination error: {str(e)}", xbmc.LOGWARNING)

        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] INDEX_GENERIC ({site_name}) failed: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", f"Failed to load {site_name or 'page'}.")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

def EPISODE_GENERIC(url, site_name=''):
    html = OpenURL_KH(url, as_text=True)
    if not html:
        xbmc.log(f"[{ADDON_ID}] EPISODE_GENERIC ({site_name}) failed to fetch: {url}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", f"Failed to load {site_name or 'page'} episode list.")
        return

    decoded = html.decode("utf-8", errors="ignore") if isinstance(html, bytes) else html
    soup = BeautifulSoup(decoded, "html.parser")

    # --- Detect submitter (optional tag or pattern) ---
    submitter = ""
    m = re.search(r"Submitter:\s*<b[^>]*>([^<]+)</b>", decoded, re.IGNORECASE)
    if m:
        submitter = m.group(1).strip()
        xbmc.log(f"[{ADDON_ID}] Found submitter: {submitter}", xbmc.LOGINFO)

    # --- Episode parsing ---
    episodes = []
    for a in soup.select("table#latest-videos a[href], div.col-xs-6.col-sm-6.col-md-3 a[href]"):
        v_link = urljoin(url, a['href'])
        v_title = a.get_text(strip=True)
        episodes.append(v_link)

    # --- Rename sequentially as Episode 01, 02, 03... ---
    if episodes:
        episodes.reverse()
        for i, v_link in enumerate(episodes, start=1):
            v_title = f"Episode {i:02d}"
            if submitter:
                v_title += f" [COLOR grey](by {submitter})[/COLOR]"
            addLink(v_title, v_link, "videolinks", '')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    player_list = []
    m = re.search(r"options\.player_list\s*=\s*(\[[^\]]+\])\s*;", decoded, re.DOTALL)
    if m:
        try:
            player_list = json.loads(m.group(1))
        except:
            pass

    if not player_list:
        m = re.search(r"const\s+videos\s*=\s*(\[[\s\S]+?\])\s*;", decoded)
        if m:
            raw = m.group(1)
            raw = re.sub(r",\s*([\]}])", r"\1", raw)
            raw = re.sub(r'([{\s,])(\w+)\s*:', r'\1"\2":', raw)
            raw = raw.replace("'", '"')
            try:
                player_list = json.loads(raw)
            except:
                pass

    if player_list:
        for i, item in enumerate(player_list, start=1):
            v_link = (item.get('file') or '').strip()
            if not v_link:
                continue
            v_title = f"Episode {i:02d}"
            if submitter:
                v_title += f" [COLOR grey](by {submitter})[/COLOR]"
            if v_link.endswith((".mp4", ".m3u8")):
                addLink(v_title, v_link, "play_direct", '')
            else:
                addLink(v_title, v_link, "video_hosting", '')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    xbmc.log(f"[{ADDON_ID}] EPISODE_GENERIC ({site_name}) no episodes found: {url}", xbmc.LOGWARNING)
    xbmcgui.Dialog().ok("No Episodes Found", "Sorry, no playable episodes were detected.")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

# ── Shared playback handlers ────────────────────
from resources.lib.handlers_playback import (
    VIDEOLINKS,
    enable_inputstream_adaptive,
    Playloop,
    VIDEO_HOSTING,
    Play_VIDEO,
)

# ────────────────────────────────────────────────
#  BASIC DIRECTORY HELPERS
# ────────────────────────────────────────────────
def addDir(name, url, action, icon=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
    u = f"{sys.argv[0]}?url={quote_plus(url)}&action={quote_plus(action)}&name={quote_plus(name)}"
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=True)

def addLink(name, url, action, icon=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
    li.setProperty("IsPlayable", "true")
    u = f"{sys.argv[0]}?url={quote_plus(url)}&action={quote_plus(action)}&name={quote_plus(name)}"
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=False)   
