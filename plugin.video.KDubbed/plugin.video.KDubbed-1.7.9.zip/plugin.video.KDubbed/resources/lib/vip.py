# ────────────────────────────────────────────────
#  VIP SITE HANDLER
# ────────────────────────────────────────────────
import re, sys, json, xbmc, xbmcplugin, xbmcgui
from urllib.parse import urljoin, quote_plus, unquote_plus
from bs4 import BeautifulSoup

# ── Local Handlers ──────────────────────────────
from resources.lib.handlers_khmer import (
    OpenSoup as OpenSoup_KH,
    OpenURL as OpenURL_KH,
)
from resources.lib.handlers_common import USER_AGENT
from resources.lib.handlers_blogid import ADDON_ID
try:
    ADDON_ID
except NameError:
    ADDON_ID = "plugin.video.KDubbed"
    
# ── Kodi Plugin Handle ──────────────────────────
VIP          = 'https://phumikhmer.vip/'
PLUGIN_HANDLE = int(sys.argv[1])


############## vip ****************** 
def INDEX_VIP(url):
    _render_vip_listing(url) 

def SINDEX_VIP(url):
    _render_vip_listing(url, label_suffix=" [COLOR green]Vip[/COLOR]", include_pagination=False)

def _render_vip_listing(url, label_color=None, label_suffix="", include_pagination=True):
    soup, html = OpenSoup_KH(url, return_html=True)

    # ------- 1 · Video cards -------------------------------------------------
    for art in soup.find_all('article', class_=re.compile(r'listing-item-grid')):
        h2_tag = art.find('h2', class_='title')
        a_tag = h2_tag.find('a') if h2_tag else None
        feat_a = art.select_one('div.featured a')

        if not (a_tag and feat_a):
            continue

        v_link  = urljoin(url, a_tag['href'])
        v_title = a_tag.get_text(strip=True)
        img_tag = art.select_one('div.featured img')
        v_image = feat_a.get('data-src') or (img_tag.get('src') if img_tag else "")
        v_image = urljoin(url, v_image) if v_image else ""
        v_image = re.sub(r'/s\d+(-[a-z]+)*/', '/s1600/', v_image) if v_image else v_image

        label = f"{v_title}{label_suffix}" if label_suffix else v_title
        if label_color:
            label = f"[COLOR {label_color}]{label}[/COLOR]"

        addDir(label, v_link, "episode_players", v_image)

    # ------- 2 · Pagination --------------------------------------------------
    if include_pagination:
        next_link = soup.find('link', rel='next')
        if next_link and next_link.get('href'):
            page_url = urljoin(url, next_link['href'])
            xbmc.log(f"[VIP] Next page URL resolved: {page_url}", xbmc.LOGINFO)
            addDir("[B]NEXT PAGE ›[/B]", page_url, "index_vip", "")

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def EPISODE_CRAFT4U(start_url):  # vip -->t.co -->craft4u
    html = OpenURL_KH(start_url, as_text=True)
    if not html:
        xbmc.log("[KDUBBED] Failed to fetch Craft4u page", xbmc.LOGERROR)
        return

    m = re.search(r'craft4u\.top/([^/]+)-0*(\d+)/', html)
    if not m:
        xbmc.log("[KDUBBED] Could not extract series base name", xbmc.LOGERROR)
        return

    base_name = m.group(1)
    ep_numbers = re.findall(rf"{base_name}-0*(\d+)", html)
    max_ep = max(map(int, ep_numbers)) if ep_numbers else 1

    for ep in range(1, max_ep + 1):
        ep_url = f"https://www.craft4u.top/{base_name}-{ep:02d}/"
        ADDON.addLink(f"Episode {ep}", ep_url, "craft4u_play", '')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def PLAY_CRAFT4U(ep_url):
    if "tvsabay.com" in ep_url:
        xbmc.log(f"[{ADDON.ADDON_ID}] WARNING: PLAY_CRAFT4U called with Tvsabay URL ({ep_url}). "
                 f"This should go to play_direct instead.", xbmc.LOGWARNING)
        return

    html = OpenURL_KH(ep_url, as_text=True)
    if not html:
        xbmc.log(f"[{ADDON.ADDON_ID}] Failed to load Craft4u episode page", xbmc.LOGERROR)
        return

    iframe = re.search(r'<iframe[^>]+src=[\'"]([^\'"]+)', html, re.IGNORECASE)
    if iframe:
        vurl = iframe.group(1)
        xbmc.log(f"[{ADDON.ADDON_ID}] Craft4u iframe found: {vurl}", xbmc.LOGINFO)
        VIDEO_HOSTING(vurl)
        return

    m = re.search(r'sources\s*:\s*\[\{file\s*:\s*"([^"]+)"', html, re.IGNORECASE)
    if m:
        vurl = m.group(1).replace("\\/", "/")
        xbmc.log(f"[{ADDON.ADDON_ID}] Craft4u JWPlayer source: {vurl}", xbmc.LOGINFO)
        vurl = f"{vurl}|Referer=https://www.craft4u.top/&User-Agent={USER_AGENT}"
        Play_VIDEO(vurl)
        return

    m = re.search(r'file:\s*"([^"]+\.(?:mp4|m3u8|aaa\.mp4|gaa\.mp4))"', html)
    if m:
        vurl = m.group(1).replace("\\/", "/")
        xbmc.log(f"[{ADDON.ADDON_ID}] Craft4u direct source: {vurl}", xbmc.LOGINFO)
        vurl = f"{vurl}|Referer=https://www.craft4u.top/&User-Agent={USER_AGENT}"
        Play_VIDEO(vurl)
        return

    xbmc.log(f"[{ADDON.ADDON_ID}] No video source found in Craft4u page", xbmc.LOGERROR)
    xbmcgui.Dialog().ok("Playback Failed", "No playable video source found.")

# ── Shared playback handlers ────────────────────
from resources.lib.handlers_playback import (
    resolve_redirect,
    VIDEOLINKS,
    enable_inputstream_adaptive,
    Playloop,
    VIDEO_HOSTING,
    Play_VIDEO,
)   
 
def addDir(name, url, action, icon=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
    u = f"{sys.argv[0]}?url={quote_plus(url)}&action={quote_plus(action)}&name={quote_plus(name)}"
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=True)

def addLink(name, url, action, icon=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
    li.setProperty("IsPlayable", "true")
    u = f"{sys.argv[0]}?url={quote_plus(url)}&action={quote_plus(action)}&name={quote_plus(name)}"
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=False)    
