# constants.py
khmertv = "aHR0cHM6Ly9kbC5kcm9wYm94dXNlcmNvbnRlbnQuY29tL3Mvcm9xcTdsdzE4czBiOTh6L2RvZGdlLnhtbA=="
