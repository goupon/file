import urllib,urllib2,re
import os,sys
import base64
import requests
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui,xbmc
import json #For VIMEO
import cookielib,os,string,cookielib,StringIO,gzip
import urlresolver
import pickle
import YDStreamUtils
import YDStreamExtractor
YDStreamExtractor.disableDASHVideo(True)
PLUGIN = xbmcaddon.Addon(id='plugin.video.khmerdl')
addon_name = 'plugin.video.khmerdl'
USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"
downloadpath = xbmc.translatePath('special://profile/')
datapath = xbmc.translatePath('special://profile/addon_data/'+addon_name+'/cookies/')
filename = os.path.join(downloadpath,'sources.xml')
cookiejar = os.path.join(datapath,'khmerstream.lwp')
ADDON_PATH = PLUGIN.getAddonInfo('path')
#append lib directory
sys.path.append( os.path.join( ADDON_PATH, 'resources', 'lib' ) )
from net import Net
from BeautifulSoup import BeautifulSoup
import CommonFunctions #For VIMEO
common = CommonFunctions
net = Net()

pluginhandle = int(sys.argv[1])

# example of how to get path to an image
SearchImage = os.path.join(ADDON_PATH, 'resources', 'images','search.png')
KhmeraveImage = os.path.join(ADDON_PATH, 'resources', 'images','khmerave.png')
MerlkonImage = os.path.join(ADDON_PATH, 'resources', 'images','merlkon.png')
KStreamImage = os.path.join(ADDON_PATH, 'resources', 'images','khmerstream.png')
fanart = os.path.join(ADDON_PATH, 'resources', 'images','Angkor.jpg')

def OpenURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link 

def OpenSoup(url):
    req = urllib2.Request(url)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20130406 Firefox/23.0')
    response = urllib2.urlopen(req).read()
    return response
	
def download():
    f = open(filename, "r")
    text = f.read()
    match=re.compile('<name>khmerdl</name>\n\s*<path pathversion=\"1\">(.+?)</path>').findall(text)[0]
    return match
	
dpath = download()

		  
def VIDEOLINKS(url):       
           link=OpenNET(url)
           url = re.compile('Base64.decode\("(.+?)"\)').findall(link)
           if(len(url) > 0):
            host=url[0].decode('base-64')
            match=re.compile('frameborder=".+?" src="(.+?)" scrolling="no"').findall(host)[0]
            VIDEO_HOSTING(match)
            #Play_VIDEO(match)
           else:
            match=re.compile('"file": "(.+?)"').findall(link)
            #match=re.compile('<IFRAME SRC="\r\n(.+?)" [^>]*').findall(link)
            if(len(match) == 0):
             match=re.compile('file:\s*"([^"]+?)"').findall(link)# Good Link
             if(len(match) == 0):
              match=re.compile('<iframe src="(.+?)" class="video allowfullscreen="true">').findall(link)
              if(len(match) == 0):
                match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)">').findall(link)
                if(len(match)==0):
                 match=re.compile('<IFRAME SRC="(.+?)" [^>]*').findall(link)
                 if(len(match) == 0):   
                   #match=re.compile('<iframe [^>]*src="(.+?)" [^>]*').findall(link)
                   match=re.compile("'file': '(.+?)',").findall(link)
                   if(len(match) == 0):
                    match=re.compile('<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                    if(len(match) == 0):
                     match = re.compile("var flashvars = {file: '(.+?)',").findall(link)        
                     if(len(match) == 0):       
                      match = re.compile('swfobject\.embedSWF\("(.+?)",').findall(link)
                      if(len(match) == 0):
                       match = re.compile("'file':\s*'(.+?)'").findall(link)
                       if(len(match) == 0):
                        match = re.compile("file: '(.+?)'").findall(link)
                        if(len(match) == 0):
                         match = re.compile('"src": "(.+?)"').findall(link)
                         if(len(match) == 0):                    
                          match = re.compile('<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                          if(len(match)== 0):
                           match = re.compile('<source [^>]*src="([^"]+?)"').findall(link)
                           if(len(match) == 0):                    
                            match = re.compile('<script>\nvidId = \'(.+?)\'; \n</script>').findall(link)
                            for url in match:
                             vid = url[0].replace("['']", "")       
                             match ='https://docs.google.com/file/d/'+ (vid)+'/preview'
                             #REAL_VIDEO_HOST(match)
                             VIDEO_HOSTING(match)
                             print match
           VIDEO_HOSTING(match[0])
           print match
           xbmcplugin.endOfDirectory(pluginhandle)
   
def VIDEO_HOSTING(vlink):
          
           if 'dailymotion' in vlink:                
                VideoURL = DAILYMOTION(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Dailymotion Loading selected video)")
                Play_VIDEO(VideoURL)
           elif 'facebook.com' in vlink:   
                VideoURL = FACEBOOK(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Facebook Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'ok.ru' in vlink:   
                VideoURL = OK(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,OK Loading selected video)")
                Play_VIDEO(VideoURL)
                
           elif 'google.com' in vlink:   
                VideoURL = DOCS_GOOGLE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Google Loading selected video)")
                Play_VIDEO(VideoURL)
                
           elif 'vimeo' in vlink:
                 VideoURL = VIMEO(vlink)
                 print 'VideoURL: %s' % VideoURL
                 #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vimeo Loading selected video)")
                 Play_VIDEO(VideoURL)

           elif 'vid.me' in vlink:                   
                VideoURL = VIDDME(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vid.me Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'fembed.com' in vlink:                   
                VideoURL = FEMBED(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Vid.me Loading selected video)")
                Play_VIDEO(VideoURL)
				
           elif 'sendvid.com' in vlink:
                VideoURL = SENDVID(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Sendvid Loading selected video)")
                Play_VIDEO(VideoURL)
           elif 'viddme' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Viddme Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'az665436' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,AZ Loading selected video)")
                Play_VIDEO(VideoURL)

           elif 'd1wst0behutosd' in vlink:
                #link = OpenURL(vlink)   
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,d1wst0behutosd Loading selected video)")
                Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))# MP4
           #     Play_VIDEO(VideoURL)

           elif 'mp4upload.com' in vlink:
                VideoURL = MP4UPLOAD(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,MP4UPLOAD Loading selected video)")
                Play_VIDEO(VideoURL)
           elif 'videobam' in vlink:  
                VideoURL = VIDEOBAM(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Videobam Loading selected video)")                                
                Play_VIDEO(VideoURL)     

           elif 'sharevids.net' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Sharevids Loading selected video)")
                Play_VIDEO(VideoURL)   
                    # d = xbmcgui.Dialog()
                    # d.ok('Not Implemented','Sorry videos on linksend.net does not work','Site seem to not exist')                
           elif 'videos4share.com' in vlink:
                VideoURL = vlink
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,videos4share Loading selected video)")
                #Play_VIDEO(VideoURL)
                Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))# MP4
           elif 'youtu.be' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")            
                Play_VIDEO(VideoURL)     

           elif 'youtube' in vlink:                   
                VideoURL = YOUTUBE(vlink)
                print 'VideoURL: %s' % VideoURL
                #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Youtube Loading selected video)")
                Play_VIDEO(VideoURL)
           else:
                #if 'grayshare.net' in vlink:
                if 'share.net' in vlink:    
                    VideoURL = vlink
                    print 'VideoURL: %s' % VideoURL
                    Play_VIDEO(urllib2.unquote(VideoURL).decode("utf8"))    
                      # d = xbmcgui.Dialog()
                      # d.ok('Not Implemented','Sorry videos on linksend.net does not work','Site seem to not exist')                
               
                else:
                    print 'VideoURL: %s' % vlink
                    #xbmc.executebuiltin("XBMC.Notification(Please Wait!,Let Try to Play These Video)")
                    Play_VIDEO(urllib2.unquote(vlink).decode("utf8"))
                    #VideoURL = urlresolver.HostedMediaFile(url=vlink).resolve()
                    #Play_VIDEO(VideoURL)

def OpenNET(url):
    try:
       net = Net(cookie_file=cookiejar)
       #net = Net(cookiejar)
       try:
            second_response = net.http_GET(url)
       except:
            second_response = net.http_GET(url.encode("utf-8"))
       return second_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')
	

def Play_VIDEO(VideoURL):

    print 'PLAY VIDEO: %s' % VideoURL    
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(pluginhandle, True, item)

###################### Resolver Start  ###################
def DAILYMOTION(SID):
	vid = YDStreamExtractor.getVideoInfo(SID,quality=1)
	path = dpath
	YDStreamExtractor.handleDownload(vid,bg=True,path=path)

def DOCS_GOOGLE(Video_ID):
	vid = YDStreamExtractor.getVideoInfo(Video_ID,quality=1)
	path = dpath
	YDStreamExtractor.handleDownload(vid,bg=True,path=path)

def FACEBOOK (SID):
	vid = YDStreamExtractor.getVideoInfo(SID,quality=1)
	path = dpath
	YDStreamExtractor.handleDownload(vid,bg=True,path=path)
	   
def OK(Video_ID):
	media_id =re.compile("//ok.ru/.+?/(.+)").findall(Video_ID)[0]
	SID = "https://ok.ru/video/%s" % media_id
	vid = YDStreamExtractor.getVideoInfo(SID,quality=1)
	path = dpath
	YDStreamExtractor.handleDownload(vid,bg=True,path=path)

def MP4UPLOAD(SID):
       req = urllib2.Request(SID)
       req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
       response = urllib2.urlopen(req)
       link=response.read()
       response.close()    
       VideoURL=re.compile('\'file\': \'(.+?)\'').findall(link)[0]
       return VideoURL

def SENDVID(SID):
        #Video_ID = urllib.unquote_plus(SID).replace("//", "http://")
        VID = urllib2.unquote(SID).replace("//", "http://")
        req = urllib2.Request(VID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match = re.compile('<source src="([^"]+?)"').findall(link)
        #match = re.compile('<meta property="og:video:secure_url" content="([^"]+?)"').findall(link)
        #VideoURL = (match[0]).decode("utf-8")
        VideoURL =  urllib2.unquote(match[0])
        return VideoURL

def VIDDME(Video_ID):
	VideoURL = urlresolver.HostedMediaFile(url=url).resolve()
	vid = YDStreamExtractor.getVideoInfo(VideoURL,quality=1)
	path = dpath
	YDStreamExtractor.handleDownload(vid,bg=True,path=path)
		
def FEMBED(Video_ID):
	media_id = re.compile("fembed.com/v/(.+)").findall(Video_ID)[0]
	SID = 'https://www.fembed.com/api/source/%s' % media_id
	link = requests.post(SID).content
	match720p = re.compile('"file":"(.+?)".+?"720p"', re.DOTALL).findall(link)
	match480p = re.compile('"file":"(.+?)".+?"480p"', re.DOTALL).findall(link)
	match360p = re.compile('"file":"(.+?)".+?"360p"', re.DOTALL).findall(link)
	match240p = re.compile('"file":"(.+?)".+?"240p"', re.DOTALL).findall(link)
	if match720p:
		VideoURL = urllib.unquote_plus(match720p[0])
	elif match480p:
		VideoURL = urllib.unquote_plus(match480p[0])
	elif match360p:
		VideoURL = urllib.unquote_plus(match360p[0])
	elif match240p:
		VideoURL = urllib.unquote_plus(match240p[0])
	vid = YDStreamExtractor.getVideoInfo(VideoURL.replace('\/','/'),quality=None)
	path = dpath
	YDStreamExtractor.handleDownload(vid,bg=True,path=path)

def VIDEOBAM(Video_ID):        
        req = urllib2.Request(Video_ID)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()               
        match=re.compile('"url"\s*:\s*"(.+?)","').findall(link)               
        for URL in match:
            if(URL.find("mp4") > -1):
               VideoURL = URL.replace("\\","")
        return VideoURL       

def VIMEO(Video_ID):
	pickle_in = open(datapath+"dict.pickle","rb")
	referer = pickle.load(pickle_in)
	Referer = (referer[1])
	HomeURL = ("http://"+Video_ID.split('/')[2])
	if 'player' in Video_ID:
		media_id =re.compile("//player.vimeo.com/video/(.+?)\?").findall(Video_ID+'?')
	elif 'vimeo' in Video_ID:
			media_id =re.compile("//vimeo.com/(.+)").findall(Video_ID+'?')
	SID = "https://player.vimeo.com/video/%s?api=1&amp;player_id=video_player" % media_id[0]  
	headers = {'Referer': Referer}
	link = requests.get(SID, headers=headers)
	VideoURL = re.compile('"progressive".+?"video/mp4".+?"url":"(.+?)"').findall(link.content)[0]	
	vid = YDStreamExtractor.getVideoInfo(VideoURL,quality=1)
	path = dpath
	YDStreamExtractor.handleDownload(vid,bg=True,path=path)
		
def YOUTUBE(SID):
	vid = YDStreamExtractor.getVideoInfo(SID,quality=1)
	path = dpath
	YDStreamExtractor.handleDownload(vid,bg=True,path=path)
###################### Resolver End  ###################        
def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultImage", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        liz.setProperty('IsPlayable', 'true')
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="http://www.khmeravenue.com/wp-content/themes/avenue/img/logo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param    



params=get_params()
url=None
name=None
mode=None
play=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass	

		
sysarg=str(sys.argv[1]) 
if mode==None or url==None or len(url)<1:
        #OtherContent()
        HOME()
elif mode==3:
        VIDEOLINKS(url)
elif mode==4:
        VIDEO_HOSTING(url)		
elif mode==100:
        PLAYLIST_VIDEOLINKS(url)
xbmcplugin.endOfDirectory(int(sysarg))
        
