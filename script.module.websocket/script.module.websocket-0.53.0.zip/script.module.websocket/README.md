script.module.websocket
=======================

websocket-client library repacked for Kodi

- https://github.com/back-to/script.module.websocket

Availability ZIP files can be found at

- https://github.com/back-to/repo

Based on websocket-client library for Python.

- https://github.com/websocket-client/websocket-client
- https://pypi.org/project/websocket-client/#files

License
-------

LGPL
