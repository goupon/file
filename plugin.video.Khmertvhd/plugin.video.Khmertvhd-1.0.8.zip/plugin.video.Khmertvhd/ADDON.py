import urllib,urllib2,re
import cookielib,os,string,cookielib,StringIO,dodge,gzip
import os,sys
import base64
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui,xbmc
import json #For VIMEO
PLUGIN = xbmcaddon.Addon(id='plugin.video.Khmertvhd')
addon_name = 'plugin.video.Khmertvhd'
Icon = 'http://radio.js-cambodia.com/'
USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"
datapath = xbmc.translatePath('special://profile/addon_data/'+addon_name)
cookiejar = os.path.join(datapath,'khmerstream.lwp')
ADDON_PATH = PLUGIN.getAddonInfo('path')
#append lib directory
sys.path.append( os.path.join( ADDON_PATH, 'resources', 'lib' ) )
from net import Net
from BeautifulSoup import BeautifulSoup
import CommonFunctions #For VIMEO
common = CommonFunctions
net = Net()
pluginhandle = int(sys.argv[1])

# example of how to get path to an image
TVHDImage = os.path.join(ADDON_PATH, 'resources', 'images','tvhd.png')
PPCTVImage = os.path.join(ADDON_PATH, 'resources', 'images','ppctv.png')
fanart = os.path.join(ADDON_PATH, 'resources', 'images','Angkor.jpg')
radio = os.path.join(ADDON_PATH, 'resources', 'images','radio.png')

def HOME():
	link = dodge.channel()
	try:
		link =link.encode("UTF-8")
	except: pass
	match=re.compile("<title>(.+?)</title>\s*<link>(.+?)</link>\s*<thumbnail>(.+?)</thumbnail>").findall(link)
	for vLinkName,vLink,vImage in match: 
		addLink(vLinkName,vLink,4,vImage)
	addDir('Radio',dodge.radio,6,radio+'')
		
def PPCTVCHANNEL(url):
	link = dodge.link(url)
	try:
		link = link.encode("UTF-8")
	except: pass
	newlink = ''.join(link.splitlines()).replace('\n','')
	match=re.compile('<pubDate>(.+?)<.+?><link>(.+?)</link><ref>(.+?)</.+?>').findall(newlink.replace('<![CDATA[','').replace(']]>',''))
	for vLink,vImage,vLinkName in match:
		addLink(vLinkName.replace('</ref>','Fresh News'),vLink,4,vImage)
		
def RADIO(url):
	link = dodge.link(url)
	try:
		link =link.encode("UTF-8")
	except: pass
	match=re.compile('"_name_short":"(.+?)".+?,"_icon":"(.+?)","_pub_date":.+?,"_stream_url":"(.+?)"').findall(link)
	for vname,vimage,vurl in match:
		addLink(vname,vurl.replace("\/","/"),4,Icon+vimage.replace("\/","/"))  

def VIDEOLINKS(url):       
           
           link=OpenNET(url)
           url = re.compile('Base64.decode\("(.+?)"\)').findall(link)
           if(len(url) > 0):
            host=url[0].decode('base-64')
            match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)"[^>]*>').findall(host)[0]
            VIDEO_HOSTING(match)
            #Play_VIDEO(match)
           else:
           #match=re.compile("'file': '(.+?)',").findall(link)
            match=re.compile('<IFRAME SRC="\r\n(.+?)" [^>]*').findall(link)
            if(len(match) == 0):
             match=re.compile('<!\[CDATA\[(.*?)\]\]></tvurl>').findall(link)# Good Link
             if(len(match) == 0):
              match=re.compile('<iframe [^>]*src="(.+?)"').findall(link)
              if(len(match) == 0):
                match=re.compile('<iframe frameborder="0" [^>]*src="(.+?)">').findall(link)
                if(len(match)==0):
                 match=re.compile('<IFRAME SRC="(.+?)" [^>]*').findall(link)
                 if(len(match) == 0):   
                   #match=re.compile('<iframe [^>]*src="(.+?)" [^>]*').findall(link)
                   match=re.compile("'file': '(.+?)',").findall(link)
                   if(len(match) == 0):
                    match=re.compile('<div class="video_main">\s*<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                    if(len(match) == 0):
                     match = re.compile("var flashvars = {file: '(.+?)',").findall(link)        
                     if(len(match) == 0):       
                      match = re.compile('swfobject\.embedSWF\("(.+?)",').findall(link)
                      if(len(match) == 0):
                       match = re.compile("'file':\s*'(.+?)'").findall(link)
                       if(len(match) == 0):                    
                        match = re.compile('<iframe [^>]*src=["\']?([^>^"^\']+)["\']?[^>]*>').findall(link)
                        if(len(match)== 0):
                         match = re.compile('<source [^>]*src="([^"]+?)"').findall(link)
                         if(len(match) == 0):                    
                          match = re.compile('<script>\nvidId = \'(.+?)\'; \n</script>').findall(link)
                          for url in match:
                           vid = url[0].replace("['']", "")       
                           match ='https://docs.google.com/file/d/'+ (vid)+'/preview'
                           #REAL_VIDEO_HOST(match)
                           VIDEO_HOSTING(match)
                           print match
           VIDEO_HOSTING(match[0])
           print match
           xbmcplugin.endOfDirectory(pluginhandle)
   
def VIDEO_HOSTING(vlink):
	link = dodge.play(url)
	Play_VIDEO(link)

def OpenNET(url):
    try:
       net = Net(cookie_file=cookiejar)
       #net = Net(cookiejar)
       try:
            second_response = net.http_GET(url)
       except:
            second_response = net.http_GET(url.encode("utf-8"))
       return second_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')
	

def Play_VIDEO(VideoURL):

    print 'PLAY VIDEO: %s' % VideoURL    
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(pluginhandle, True, item)

###################### Resolver Start  ###################

###################### Resolver End  ###################        
def addLink(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultImage", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        liz.setProperty('IsPlayable', 'true')
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=TVHDImage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param    



params=get_params()
url=None
name=None
mode=None
play=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass	

		
sysarg=str(sys.argv[1]) 
if mode==None or url==None or len(url)<1:
        #OtherContent()
        HOME()
elif mode==3:
        VIDEOLINKS(url)
elif mode==4:
        VIDEO_HOSTING(url)
elif mode==5:
        PPCTVCHANNEL(url)
elif mode==6:
        RADIO(url)		
elif mode==100:
        PLAYLIST_VIDEOLINKS(url)
xbmcplugin.endOfDirectory(int(sysarg))
        
