# script.module.streamlink-plugins

For plugin issues visit https://github.com/back-to/plugins/issues

- Issue Tracker: https://github.com/back-to/plugins/issues
- Github: https://github.com/back-to/plugins
- Kodi Github: https://github.com/back-to/script.module.back-to-plugins
- Repo: https://github.com/back-to/repo
- Repo-Zip: https://github.com/back-to/repo/raw/master/repository.back-to/repository.back-to-5.0.0.zip

# Guide

This addon can be used for your own custom streamlink plugins.

It won't be updated in this repo, so you can create your own repo
or just update it from a zip file.

Put your custom plugins into `lib/data/` and install the updated addon.

LiveProxy will search automatically for plugins in this folder.
