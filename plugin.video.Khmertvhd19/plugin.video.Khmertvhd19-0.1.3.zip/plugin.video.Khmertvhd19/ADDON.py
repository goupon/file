import six
from six import BytesIO
from six.moves.urllib.parse import quote
from six.moves.urllib import parse as urllib
from six.moves.urllib_response import addinfourl
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
if six.PY3:
    from http import cookiejar as cookielib
else:
    import cookielib
import os,sys,re
if sys.version_info[0] > 2:
    unicode = str
import dodge
import base64
import requests
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui,xbmc
import json #For VIMEO
import os,string,gzip
from bs4 import BeautifulSoup
import resolveurl
PLUGIN = xbmcaddon.Addon(id='plugin.video.Khmertvhd19')
addon_name = 'plugin.video.Khmertvhd19'
Icon = 'http://radio.js-cambodia.com/'
USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/16.0.1"
datapath = xbmc.translatePath('special://profile/addon_data/'+addon_name)
cookiejar = os.path.join(datapath,'khmerstream.lwp')
ADDON_PATH = PLUGIN.getAddonInfo('path')
#append lib directory
sys.path.append( os.path.join( ADDON_PATH, 'resources', 'lib' ) )
from t0mm0.common.addon import Addon
from t0mm0.common.net import Net

pluginhandle = int(sys.argv[1])

# example of how to get path to an image
TVHDImage = os.path.join(ADDON_PATH, 'resources', 'images','tvhd.png')
PPCTVImage = os.path.join(ADDON_PATH, 'resources', 'images','ppctv.png')
fanart = os.path.join(ADDON_PATH, 'resources', 'images','Angkor.jpg')
radio = os.path.join(ADDON_PATH, 'resources', 'images','radio.png')

def HOME():
	link = dodge.channel(url)
	try:
		link =link.encode("UTF-8")
	except: pass
	match=re.compile("<title>(.+?)</title>\s*<link>(.+?)</link>\s*<thumbnail>(.+?)</thumbnail>").findall(link.decode('utf-8'))
	for vLinkName,vLink,vImage in match: 
		addLink(vLinkName,vLink,4,vImage)



def Play(url):
    Play_VIDEO(url)

def OpenNET(url):
    try:
       net = Net(cookie_file=cookiejar)
       #net = Net(cookiejar)
       try:
            second_response = net.http_GET(url)
       except:
            second_response = net.http_GET(url.encode("utf-8"))
       return second_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')
	

def Play_VIDEO(VideoURL):

    print ('PLAY VIDEO: %s' % VideoURL)   
    item = xbmcgui.ListItem(path=VideoURL)
    return xbmcplugin.setResolvedUrl(pluginhandle, True, item)

###################### Resolver Start  ###################

###################### Resolver End  ###################        
def addLink(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({'poster': iconimage})
		liz.setArt({'icon': iconimage})
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		liz.setProperty("IsPlayable","true")
		contextMenuItems = []
		liz.addContextMenuItems(contextMenuItems, replaceItems=True)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
		return ok
		
def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({'poster': iconimage})
		liz.setArt({'icon': iconimage})
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param    



params=get_params()
url=None
name=None
mode=None
play=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass	

		
sysarg=str(sys.argv[1]) 
if mode==None or url==None or len(url)<1:
        #OtherContent()
        HOME()
elif mode==4:
        Play(url)
elif mode==100:
        PLAYLIST_VIDEOLINKS(url)
xbmcplugin.endOfDirectory(int(sysarg))
        
